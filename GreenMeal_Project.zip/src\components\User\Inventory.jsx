'use client';

import React, { useState, useEffect, useRef } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Button } from "@/components/ui/button";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Loader2, Plus, Minus, Edit, Trash2, Camera, PackagePlus } from 'lucide-react';
import { toast } from 'sonner';
import { BaseApiUrl } from '@/utils/constanst';

const ProductTable = ({ products, onEdit, onDelete }) => (
  <Card className="mt-6 bg-white dark:bg-zinc-900 border border-green-200 dark:border-zinc-800 shadow-md">
    <CardHeader className="bg-green-100/50 dark:bg-zinc-800/50">
      <CardTitle className="text-green-800 dark:text-green-300 text-lg flex items-center justify-between">
        <span>Product Inventory ({products.length} Items)</span>
      </CardTitle>
    </CardHeader>
    <CardContent className="p-4">
      <div className="overflow-x-auto">
        <Table>
          <TableHeader>
            <TableRow>
              <TableHead className="text-green-700 dark:text-green-300">Name</TableHead>
              <TableHead className="text-green-700 dark:text-green-300">MRP</TableHead>
              <TableHead className="text-green-700 dark:text-green-300">Type</TableHead>
              <TableHead className="text-green-700 dark:text-green-300">Expiry Date</TableHead>
              <TableHead className="text-green-700 dark:text-green-300">Quantity</TableHead>
              <TableHead className="text-green-700 dark:text-green-300">Image</TableHead>
              <TableHead className="text-green-700 dark:text-green-300">Actions</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {products.map((product) => (
              <TableRow key={product._id || product.id}>
                <TableCell className="font-semibold text-zinc-900 dark:text-zinc-100">{product.itemName || product.name}</TableCell>
                <TableCell className="font-mono">₹{Number(product.mrp || 0).toLocaleString('en-IN')}</TableCell>
                <TableCell>
                  <span className="px-2 py-0.5 text-xs bg-emerald-100 text-emerald-800 dark:bg-emerald-950 dark:text-emerald-300 rounded-full font-medium">
                    {product.type || 'General'}
                  </span>
                </TableCell>
                <TableCell className="text-xs text-zinc-600 dark:text-zinc-400">
                  {product.Expirydate || product.expiryDate ? new Date(product.Expirydate || product.expiryDate).toLocaleDateString('en-IN') : 'N/A'}
                </TableCell>
                <TableCell className="font-semibold text-emerald-700 dark:text-emerald-400">
                  {product.Quantity || product.quantity || 0}
                </TableCell>
                <TableCell>
                  {product.Imageurl || product.image ? (
                    <img src={product.Imageurl || product.image} alt={product.itemName || product.name} className="w-12 h-12 object-cover rounded-lg border" />
                  ) : (
                    <div className="w-12 h-12 bg-zinc-100 dark:bg-zinc-800 rounded-lg flex items-center justify-center text-xs text-zinc-400">
                      No img
                    </div>
                  )}
                </TableCell>
                <TableCell>
                  <div className="flex items-center gap-2">
                    <Button size="sm" variant="outline" onClick={() => onEdit(product)} className="h-8 w-8 p-0">
                      <Edit className="h-4 w-4 text-emerald-600" />
                    </Button>
                    <Button size="sm" variant="outline" onClick={() => onDelete(product._id || product.id)} className="h-8 w-8 p-0 border-red-200 text-red-600 hover:bg-red-50">
                      <Trash2 className="h-4 w-4" />
                    </Button>
                  </div>
                </TableCell>
              </TableRow>
            ))}
          </TableBody>
        </Table>
      </div>
    </CardContent>
  </Card>
);

const ProductForm = ({ product, onAddProduct, onUpdateProduct, setIsDialogOpen, openCamera, productImage, userData }) => {
  const [formData, setFormData] = useState(product ? {
    name: product.itemName || product.name || '',
    mrp: product.mrp || '',
    type: product.type || '',
    expiryDate: product.Expirydate || product.expiryDate || '',
    quantity: product.Quantity || product.quantity || '',
  } : {
    name: '',
    mrp: '',
    type: 'Vegetables',
    expiryDate: '',
    quantity: '',
  });

  const [isSubmitting, setIsSubmitting] = useState(false);

  const handleSubmit = async (e) => {
    e.preventDefault();
    if (!formData.name || !formData.mrp || !formData.expiryDate || !formData.quantity) {
      toast.error('Please fill in all required product details.');
      return;
    }

    setIsSubmitting(true);

    try {
      let imageUrl = productImage || 'https://images.unsplash.com/photo-1542838132-92c53300491e?auto=format&fit=crop&w=300&q=80';

      // Cloudinary upload if photo taken via camera
      if (productImage && productImage.startsWith('data:image')) {
        try {
          const data = new FormData();
          data.append("file", productImage);
          data.append("upload_preset", "kfdvzoaz");
          data.append("cloud_name", "dggd6cvzh");

          const res = await fetch('https://api.cloudinary.com/v1_1/dggd6cvzh/image/upload', {
            method: "POST",
            body: data
          });
          const cloudData = await res.json();
          if (cloudData?.url) {
            imageUrl = cloudData.url;
          }
        } catch (cloudErr) {
          console.warn('Cloudinary upload fallback:', cloudErr);
        }
      }

      // Backend API sync attempt
      try {
        await fetch(`${BaseApiUrl}/inventory/`, {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json'
          },
          body: JSON.stringify({
            itemName: formData.name,
            userid: userData?.user?.id || 'demo-user',
            Expirydate: formData.expiryDate,
            Imageurl: imageUrl,
            mrp: Number(formData.mrp),
            Quantity: Number(formData.quantity),
            type: formData.type
          })
        });
      } catch (apiErr) {
        console.warn('Backend API offline, saving product locally:', apiErr);
      }

      // Update state
      const createdProduct = {
        _id: product?._id || product?.id || Date.now().toString(),
        id: product?._id || product?.id || Date.now().toString(),
        itemName: formData.name,
        name: formData.name,
        mrp: Number(formData.mrp),
        type: formData.type,
        Expirydate: formData.expiryDate,
        expiryDate: formData.expiryDate,
        Quantity: Number(formData.quantity),
        quantity: Number(formData.quantity),
        Imageurl: imageUrl,
        image: imageUrl
      };

      if (product) {
        onUpdateProduct(createdProduct);
        toast.success('Product updated successfully!');
      } else {
        onAddProduct(createdProduct);
        toast.success('New product added to inventory!');
      }

      setIsDialogOpen(false);
    } catch (err) {
      console.error('Error adding product:', err);
      toast.error('Failed to save product. Please try again.');
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <form onSubmit={handleSubmit} className="space-y-4 text-xs">
      <div className="space-y-1">
        <Label htmlFor="name" className="text-zinc-700 dark:text-zinc-300 font-semibold">Product Name</Label>
        <Input
          id="name"
          value={formData.name}
          onChange={(e) => setFormData({ ...formData, name: e.target.value })}
          placeholder="e.g. Organic Tomatoes"
          className="border-green-300 focus:border-green-500 rounded-lg text-xs"
          required
        />
      </div>

      <div className="grid grid-cols-2 gap-3">
        <div className="space-y-1">
          <Label htmlFor="mrp" className="text-zinc-700 dark:text-zinc-300 font-semibold">MRP (₹)</Label>
          <Input
            id="mrp"
            type="number"
            value={formData.mrp}
            onChange={(e) => setFormData({ ...formData, mrp: e.target.value })}
            placeholder="120"
            className="border-green-300 focus:border-green-500 rounded-lg text-xs"
            required
          />
        </div>

        <div className="space-y-1">
          <Label htmlFor="quantity" className="text-zinc-700 dark:text-zinc-300 font-semibold">Quantity</Label>
          <Input
            id="quantity"
            type="number"
            value={formData.quantity}
            onChange={(e) => setFormData({ ...formData, quantity: e.target.value })}
            placeholder="50"
            className="border-green-300 focus:border-green-500 rounded-lg text-xs"
            required
          />
        </div>
      </div>

      <div className="grid grid-cols-2 gap-3">
        <div className="space-y-1">
          <Label htmlFor="type" className="text-zinc-700 dark:text-zinc-300 font-semibold">Category Type</Label>
          <Select value={formData.type} onValueChange={(value) => setFormData({ ...formData, type: value })}>
            <SelectTrigger className="border-green-300 focus:border-green-500 rounded-lg text-xs">
              <SelectValue placeholder="Select type" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="Vegetables">Vegetables</SelectItem>
              <SelectItem value="Fruits">Fruits</SelectItem>
              <SelectItem value="Dairy">Dairy</SelectItem>
              <SelectItem value="Bakery">Bakery</SelectItem>
              <SelectItem value="Canned Goods">Canned Goods</SelectItem>
            </SelectContent>
          </Select>
        </div>

        <div className="space-y-1">
          <Label htmlFor="expiryDate" className="text-zinc-700 dark:text-zinc-300 font-semibold">Expiry Date</Label>
          <Input
            id="expiryDate"
            type="date"
            value={formData.expiryDate}
            onChange={(e) => setFormData({ ...formData, expiryDate: e.target.value })}
            className="border-green-300 focus:border-green-500 rounded-lg text-xs"
            required
          />
        </div>
      </div>

      <div className="space-y-1 pt-1">
        <Label className="text-zinc-700 dark:text-zinc-300 font-semibold">Product Photo</Label>
        <div className="flex items-center gap-3">
          <Button type="button" variant="outline" onClick={openCamera} className="text-xs border-emerald-300 text-emerald-700 hover:bg-emerald-50">
            <Camera className="w-3.5 h-3.5 mr-1.5" />
            {productImage ? 'Retake Photo' : 'Capture Photo'}
          </Button>
          {productImage && (
            <img src={productImage} alt="Preview" className="w-10 h-10 object-cover rounded-lg border" />
          )}
        </div>
      </div>

      <Button type="submit" className="w-full bg-emerald-600 hover:bg-emerald-700 text-white font-semibold py-5 rounded-xl text-xs transition" disabled={isSubmitting}>
        {isSubmitting ? (
          <>
            <Loader2 className="mr-2 h-4 w-4 animate-spin" />
            Saving Product...
          </>
        ) : (
          product ? 'Update Product' : 'Add Product to Inventory'
        )}
      </Button>
    </form>
  );
};

const Inventory = ({ userData }) => {
  const [products, setProducts] = useState([]);
  const [isDialogOpen, setIsDialogOpen] = useState(false);
  const [isCameraOpen, setIsCameraOpen] = useState(false);
  const [capturedImage, setCapturedImage] = useState(null);
  const [editingProduct, setEditingProduct] = useState(null);
  const videoRef = useRef(null);
  const canvasRef = useRef(null);

  useEffect(() => {
    const fetchProducts = async () => {
      try {
        if (userData?.user?.id) {
          const response = await fetch(`${BaseApiUrl}/inventory/`, {
            method: 'GET',
            headers: {
              'Content-Type': 'application/json',
              "userid": userData.user.id
            },
          });
          const json = await response.json();
          if (json?.resume && Array.isArray(json.resume) && json.resume.length > 0) {
            setProducts(json.resume);
            return;
          }
        }
      } catch (error) {
        console.warn('Error fetching inventory products, using local fallback items:', error);
      }

      setProducts([
        { _id: '1', itemName: 'Fresh Organic Apples', mrp: 120, type: 'Fruits', Expirydate: '2026-09-10', Quantity: 50, Imageurl: 'https://images.unsplash.com/photo-1560806887-1e4cd0b6cbd6?auto=format&fit=crop&w=200&q=80' },
        { _id: '2', itemName: 'Farm Organic Carrots', mrp: 40, type: 'Vegetables', Expirydate: '2026-09-08', Quantity: 80, Imageurl: 'https://images.unsplash.com/photo-1598170845058-12ef4a457939?auto=format&fit=crop&w=200&q=80' },
        { _id: '3', itemName: 'Whole Grain Bread', mrp: 65, type: 'Bakery', Expirydate: '2026-09-04', Quantity: 20, Imageurl: 'https://images.unsplash.com/photo-1509440159596-0249088772ff?auto=format&fit=crop&w=200&q=80' },
      ]);
    };
    fetchProducts();
  }, [userData?.user?.id]);

  const handleAddProduct = (newProduct) => {
    setProducts(prev => [newProduct, ...prev]);
  };

  const handleUpdateProduct = (updatedProduct) => {
    setProducts(prev => prev.map(p => (p._id === updatedProduct._id || p.id === updatedProduct.id) ? updatedProduct : p));
  };

  const handleDeleteProduct = (id) => {
    setProducts(prev => prev.filter(p => (p._id !== id && p.id !== id)));
    toast.success('Product removed from inventory');
  };

  const openCamera = async () => {
    setIsCameraOpen(true);
    try {
      const stream = await navigator.mediaDevices.getUserMedia({
        video: { facingMode: 'user' },
      });
      if (videoRef.current) {
        videoRef.current.srcObject = stream;
        videoRef.current.play();
      }
    } catch (err) {
      console.warn("Camera access warning:", err);
      toast.info('Camera unavailable. Default product image will be used.');
    }
  };

  const capturePhoto = () => {
    const video = videoRef.current;
    const canvas = canvasRef.current;
    if (video && canvas) {
      canvas.width = video.videoWidth || 300;
      canvas.height = video.videoHeight || 300;
      canvas.getContext('2d').drawImage(video, 0, 0);
      const photoUrl = canvas.toDataURL('image/jpeg');
      setCapturedImage(photoUrl);
      toast.success('Photo captured!');
    }
    closeCamera();
  };

  const closeCamera = () => {
    if (videoRef.current && videoRef.current.srcObject) {
      const stream = videoRef.current.srcObject;
      const tracks = stream.getTracks();
      tracks.forEach(track => track.stop());
    }
    setIsCameraOpen(false);
  };

  return (
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      transition={{ duration: 0.3 }}
      className="p-4 max-w-7xl mx-auto bg-green-50/50 dark:bg-zinc-950 rounded-2xl"
    >
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 mb-6">
        <div>
          <h1 className="text-2xl font-bold text-green-900 dark:text-green-100 flex items-center gap-2">
            <PackagePlus className="w-6 h-6 text-emerald-600" />
            Eco-Friendly Inventory Management
          </h1>
          <p className="text-xs text-muted-foreground">Track surplus food stock, expiry dates, and categories</p>
        </div>

        <Button 
          onClick={() => { setIsDialogOpen(true); setEditingProduct(null); setCapturedImage(null); }} 
          className="bg-emerald-600 hover:bg-emerald-700 text-white font-semibold text-xs px-4 py-5 rounded-xl shadow-sm"
        >
          <Plus className="w-4 h-4 mr-1.5" />
          Add New Product
        </Button>
      </div>

      <ProductTable
        products={products}
        onEdit={(prod) => { setEditingProduct(prod); setCapturedImage(prod.Imageurl || prod.image); setIsDialogOpen(true); }}
        onDelete={handleDeleteProduct}
      />

      {/* Add / Edit Product Modal */}
      <Dialog open={isDialogOpen} onOpenChange={setIsDialogOpen}>
        <DialogContent className="max-w-md bg-white dark:bg-zinc-900 border-green-200 dark:border-zinc-800 rounded-2xl shadow-xl">
          <DialogHeader>
            <DialogTitle className="text-emerald-800 dark:text-emerald-300 text-lg font-bold">
              {editingProduct ? 'Edit Product Details' : 'Add New Product'}
            </DialogTitle>
          </DialogHeader>
          <ProductForm
            userData={userData}
            product={editingProduct}
            onAddProduct={handleAddProduct}
            onUpdateProduct={handleUpdateProduct}
            setIsDialogOpen={setIsDialogOpen}
            openCamera={openCamera}
            productImage={capturedImage}
          />
        </DialogContent>
      </Dialog>

      {/* Camera Capture Modal */}
      <Dialog open={isCameraOpen} onOpenChange={closeCamera}>
        <DialogContent className="max-w-md bg-white dark:bg-zinc-900 border-green-200 dark:border-zinc-800 rounded-2xl">
          <DialogHeader>
            <DialogTitle className="text-emerald-800 dark:text-emerald-300 text-base font-bold">Capture Product Photo</DialogTitle>
          </DialogHeader>
          <div className="mt-2 text-center">
            <video ref={videoRef} className="w-full h-56 object-cover rounded-xl border bg-black" />
            <Button onClick={capturePhoto} className="mt-4 w-full bg-emerald-600 hover:bg-emerald-700 text-white font-semibold text-xs py-4 rounded-xl">
              Capture Photo
            </Button>
          </div>
        </DialogContent>
      </Dialog>

      <canvas ref={canvasRef} className="hidden" />
    </motion.div>
  );
};

export default Inventory;