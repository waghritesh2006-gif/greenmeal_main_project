import { NextResponse } from 'next/server';
import { CreateCompostBatchSchema } from '@/lib/validations/compostSchemas';
import { calculateBatchNutrients, estimateFinalYieldAndNpk } from '@/lib/services/compostEngine';

let compostBatchesStore = [];

export async function GET() {
  return NextResponse.json({
    success: true,
    count: compostBatchesStore.length,
    data: compostBatchesStore,
  });
}

export async function POST(req) {
  try {
    const body = await req.json();
    const validationResult = CreateCompostBatchSchema.safeParse(body);

    if (!validationResult.success) {
      return NextResponse.json({
        success: false,
        error: 'Validation Error',
        details: validationResult.error.flatten().fieldErrors,
      }, { status: 400 });
    }

    const { batchNumber, targetCnRatio, ingredients, startDate } = validationResult.data;

    // 1. Calculate nutrient blend
    const batchStats = calculateBatchNutrients(ingredients);

    // 2. Estimate final output dry yield and N-P-K nutrient ratings
    const finalYieldEst = estimateFinalYieldAndNpk(ingredients);

    const newBatch = {
      id: `batch-${Date.now()}`,
      batchNumber,
      targetCnRatio,
      calculatedCnRatio: batchStats.cnRatio,
      initialWetMassKg: batchStats.totalWetWeightKg,
      initialDryMassKg: batchStats.totalDryWeightKg,
      ingredients,
      currentPhase: 'MESOPHILIC',
      startDate: startDate || new Date().toISOString().split('T')[0],
      estimatedMaturityDate: new Date(Date.now() + 45 * 24 * 60 * 60 * 1000).toISOString().split('T')[0],
      estimatedDryYieldKg: finalYieldEst.estimatedDryYieldKg,
      estimatedNpk: finalYieldEst.npkRating,
      qualityGrade: finalYieldEst.qualityGrade,
      telemetryLogs: [],
      createdAt: new Date().toISOString(),
    };

    compostBatchesStore.push(newBatch);

    return NextResponse.json({
      success: true,
      message: 'Compost batch initialized successfully',
      data: newBatch,
    }, { status: 201 });
  } catch (error) {
    return NextResponse.json({
      success: false,
      error: 'Internal Server Error',
      message: error.message,
    }, { status: 500 });
  }
}
