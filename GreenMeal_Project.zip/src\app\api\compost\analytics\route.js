import { NextResponse } from 'next/server';

export async function GET(req) {
  const { searchParams } = new URL(req.url);
  const period = searchParams.get('period') || 'monthly';

  const multiplier = period === 'monthly' ? 30 : period === 'weekly' ? 7 : 1;

  const mockAnalytics = {
    period,
    summary: {
      activeBatchesCount: 4,
      completedBatchesCount: 12,
      totalOrganicWasteDivertedKg: 4200 * (multiplier / 30),
      totalFertilizerProducedKg: 2310 * (multiplier / 30),
      averageBlendCnRatio: 28.4,
      npkRatingDistribution: {
        avgNPercent: 2.1,
        avgPPercent: 1.4,
        avgKPercent: 1.8,
      },
      qualityCompliance: {
        gradeAPercentage: 85,
        gradeBPercentage: 15,
        heavyMetalPassRate: 100,
      },
    },
    phaseDistribution: [
      { phase: 'MESOPHILIC', count: 1 },
      { phase: 'THERMOPHILIC', count: 2 },
      { phase: 'COOLING', count: 1 },
      { phase: 'CURING', count: 2 },
    ],
  };

  return NextResponse.json({
    success: true,
    data: mockAnalytics,
  });
}
