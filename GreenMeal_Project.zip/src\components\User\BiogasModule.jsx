'use client';

import { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import { 
  Flame, Zap, Thermometer, Activity, Gauge, AlertTriangle, 
  CheckCircle2, RefreshCw, ArrowUpRight, ShieldAlert, Sparkles, Factory,
  BookOpen, Wrench, ShieldCheck, FileText, Check
} from 'lucide-react';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Badge } from '@/components/ui/badge';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { calculateBiogasYield, evaluateDigesterHealth, FEEDSTOCK_DEFAULTS } from '@/lib/services/biogasEngine';

export default function BiogasModule() {
  // Calculator State
  const [category, setCategory] = useState('CATTLE_MANURE');
  const [weightKg, setWeightKg] = useState(1000);
  const [tsPercent, setTsPercent] = useState(18);
  const [vsPercent, setVsPercent] = useState(80);
  const [methanePercent, setMethanePercent] = useState(60);
  const [yieldResult, setYieldResult] = useState(null);
  const [showToast, setShowToast] = useState(false);

  // Telemetry Log & Health State
  const [temperatureC, setTemperatureC] = useState(37.5);
  const [phLevel, setPhLevel] = useState(7.2);
  const [pressureBar, setPressureBar] = useState(0.035);
  const [storageLevelM3, setStorageLevelM3] = useState(420);
  const maxStorageM3 = 500;
  const digesterCapacityM3 = 250;
  const [healthReport, setHealthReport] = useState(null);

  // Active Manual Tab
  const [manualTab, setManualTab] = useState('sop');

  // History logs state
  const [logs, setLogs] = useState([
    {
      id: 'log-101',
      date: '2026-08-31 09:30',
      category: 'CATTLE_MANURE',
      weightKg: 1000,
      biogasM3: 43.2,
      electricityKwh: 90.18,
      lpgKg: 20.13,
      ph: 7.2,
      temp: 37.5,
      status: 'HEALTHY'
    },
    {
      id: 'log-100',
      date: '2026-08-30 16:00',
      category: 'FOOD_WASTE',
      weightKg: 500,
      biogasM3: 58.4,
      electricityKwh: 132.1,
      lpgKg: 29.47,
      ph: 6.9,
      temp: 38.0,
      status: 'HEALTHY'
    }
  ]);

  // Recalculate yields whenever calculator inputs change
  useEffect(() => {
    const res = calculateBiogasYield({
      feedstockCategory: category,
      feedstockWeightKg: weightKg,
      tsPercent,
      vsPercent,
      methaneContentPercent: methanePercent,
      digesterCapacityM3,
    });
    setYieldResult(res);
  }, [category, weightKg, tsPercent, vsPercent, methanePercent]);

  // Update feedstock default parameters when category changes
  const handleCategoryChange = (val) => {
    setCategory(val);
    const defaults = FEEDSTOCK_DEFAULTS[val] || FEEDSTOCK_DEFAULTS.OTHER;
    setTsPercent(defaults.defaultTsPercent);
    setVsPercent(defaults.defaultVsPercent);
    setMethanePercent(defaults.methaneContentPercent);
  };

  // Evaluate Health Telemetry
  useEffect(() => {
    const report = evaluateDigesterHealth(
      { temperatureC, phLevel, pressureBar },
      storageLevelM3,
      maxStorageM3
    );
    setHealthReport(report);
  }, [temperatureC, phLevel, pressureBar, storageLevelM3]);

  // Log operational entry
  const handleLogSubmit = (e) => {
    e.preventDefault();
    if (!yieldResult) return;

    const newLog = {
      id: `log-${Date.now()}`,
      date: new Date().toLocaleString(),
      category,
      weightKg: Number(weightKg),
      biogasM3: yieldResult.yield.biogasProducedM3,
      electricityKwh: yieldResult.energyOutput.electricityKwh,
      lpgKg: yieldResult.energyOutput.lpgEquivalentKg,
      ph: Number(phLevel),
      temp: Number(temperatureC),
      status: healthReport?.isHealthy ? 'HEALTHY' : 'WARNING'
    };

    setLogs([newLog, ...logs]);
    setShowToast(true);
    setTimeout(() => setShowToast(false), 3000);
  };

  return (
    <div className="space-y-6 pb-10">
      {/* Toast Banner */}
      {showToast && (
        <motion.div 
          initial={{ opacity: 0, y: -20 }} 
          animate={{ opacity: 1, y: 0 }} 
          className="fixed top-5 right-5 z-50 flex items-center gap-2 bg-emerald-600 text-white px-4 py-3 rounded-xl shadow-2xl font-medium text-sm"
        >
          <Check className="h-5 w-5" /> Operational Feeding & Telemetry Logged Successfully!
        </motion.div>
      )}

      {/* Header Banner */}
      <div className="relative overflow-hidden rounded-2xl bg-gradient-to-r from-emerald-800 via-teal-700 to-green-900 p-6 text-white shadow-xl">
        <div className="relative z-10 flex flex-col md:flex-row md:items-center justify-between gap-4">
          <div>
            <div className="inline-flex items-center gap-2 rounded-full bg-emerald-500/20 px-3 py-1 text-xs font-semibold text-emerald-200 backdrop-blur-md mb-2">
              <Sparkles className="h-3.5 w-3.5" /> Module 1: Anaerobic Digestion Technical Operating Manual
            </div>
            <h1 className="text-3xl font-extrabold tracking-tight">Biogas Plant Management & Yield Estimator</h1>
            <p className="text-emerald-100 text-sm mt-1 max-w-2xl">
              Real-time digester health telemetry, kinetic energy yield calculations, and technical standard operating procedures.
            </p>
          </div>
          <div className="flex items-center gap-3 bg-white/10 backdrop-blur-md rounded-xl p-3 border border-white/20">
            <Factory className="h-8 w-8 text-emerald-300" />
            <div>
              <p className="text-xs text-emerald-200">Digester Capacity</p>
              <p className="text-lg font-bold">{digesterCapacityM3} m³</p>
            </div>
          </div>
        </div>
        <div className="absolute -right-10 -bottom-10 h-48 w-48 rounded-full bg-emerald-500/10 blur-3xl" />
      </div>

      {/* Digester Telemetry & Health Alert Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        {/* pH Level */}
        <Card className="border-green-200 bg-white/80 dark:bg-zinc-900/80 backdrop-blur shadow-sm hover:shadow-md transition">
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium text-muted-foreground">pH Level</CardTitle>
            <Activity className={`h-4 w-4 ${phLevel < 6.5 || phLevel > 8.0 ? 'text-red-500' : 'text-emerald-600'}`} />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-emerald-950 dark:text-emerald-100">{phLevel}</div>
            <p className="text-xs text-muted-foreground mt-1">Ideal Range: 6.8 - 7.5</p>
            <div className="mt-3">
              <Label className="text-[10px] text-zinc-500">Simulate pH:</Label>
              <input 
                type="range" min="5.0" max="9.0" step="0.1" value={phLevel} 
                onChange={(e) => setPhLevel(Number(e.target.value))}
                className="w-full accent-emerald-600 cursor-pointer h-1.5 bg-zinc-200 rounded-lg"
              />
            </div>
          </CardContent>
        </Card>

        {/* Temperature */}
        <Card className="border-green-200 bg-white/80 dark:bg-zinc-900/80 backdrop-blur shadow-sm hover:shadow-md transition">
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium text-muted-foreground">Internal Temp</CardTitle>
            <Thermometer className="h-4 w-4 text-amber-500" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-emerald-950 dark:text-emerald-100">{temperatureC} °C</div>
            <p className="text-xs text-muted-foreground mt-1">Mesophilic (35-40°C)</p>
            <div className="mt-3">
              <Label className="text-[10px] text-zinc-500">Simulate Temp:</Label>
              <input 
                type="range" min="20" max="65" step="0.5" value={temperatureC} 
                onChange={(e) => setTemperatureC(Number(e.target.value))}
                className="w-full accent-amber-500 cursor-pointer h-1.5 bg-zinc-200 rounded-lg"
              />
            </div>
          </CardContent>
        </Card>

        {/* Pressure */}
        <Card className="border-green-200 bg-white/80 dark:bg-zinc-900/80 backdrop-blur shadow-sm hover:shadow-md transition">
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium text-muted-foreground">Pressure</CardTitle>
            <Gauge className="h-4 w-4 text-blue-500" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-emerald-950 dark:text-emerald-100">{pressureBar} bar</div>
            <p className="text-xs text-muted-foreground mt-1">Max threshold: 0.05 bar</p>
            <div className="mt-3">
              <Label className="text-[10px] text-zinc-500">Simulate Pressure:</Label>
              <input 
                type="range" min="0.00" max="0.08" step="0.005" value={pressureBar} 
                onChange={(e) => setPressureBar(Number(e.target.value))}
                className="w-full accent-blue-500 cursor-pointer h-1.5 bg-zinc-200 rounded-lg"
              />
            </div>
          </CardContent>
        </Card>

        {/* Storage Level */}
        <Card className="border-green-200 bg-white/80 dark:bg-zinc-900/80 backdrop-blur shadow-sm hover:shadow-md transition">
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium text-muted-foreground">Gas Storage</CardTitle>
            <Flame className="h-4 w-4 text-orange-500" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-emerald-950 dark:text-emerald-100">{storageLevelM3} / {maxStorageM3} m³</div>
            <div className="w-full bg-zinc-100 h-2 rounded-full mt-2 overflow-hidden">
              <div 
                className={`h-full rounded-full transition-all duration-300 ${
                  (storageLevelM3 / maxStorageM3) >= 0.9 ? 'bg-red-500' : 'bg-emerald-500'
                }`}
                style={{ width: `${(storageLevelM3 / maxStorageM3) * 100}%` }}
              />
            </div>
            <p className="text-[11px] text-muted-foreground mt-1 font-medium">{((storageLevelM3 / maxStorageM3) * 100).toFixed(1)}% Capacity</p>
          </CardContent>
        </Card>
      </div>

      {/* Telemetry Health Alert Center */}
      {healthReport && healthReport.alerts.length > 0 && (
        <motion.div initial={{ opacity: 0, y: -10 }} animate={{ opacity: 1, y: 0 }} className="space-y-2">
          {healthReport.alerts.map((alert, idx) => (
            <div 
              key={idx} 
              className={`flex items-start gap-3 p-4 rounded-xl border ${
                alert.severity === 'CRITICAL' 
                  ? 'bg-red-50 border-red-200 text-red-900 dark:bg-red-950/40 dark:border-red-800 dark:text-red-200' 
                  : alert.severity === 'HIGH'
                  ? 'bg-amber-50 border-amber-200 text-amber-900 dark:bg-amber-950/40 dark:border-amber-800 dark:text-amber-200'
                  : 'bg-blue-50 border-blue-200 text-blue-900 dark:bg-blue-950/40 dark:border-blue-800 dark:text-blue-200'
              }`}
            >
              <AlertTriangle className="h-5 w-5 shrink-0 mt-0.5" />
              <div className="flex-1">
                <div className="flex items-center gap-2">
                  <Badge variant="outline" className="font-mono text-[10px] uppercase font-bold">
                    {alert.severity} • {alert.code}
                  </Badge>
                </div>
                <p className="text-sm mt-1 font-medium">{alert.message}</p>
              </div>
            </div>
          ))}
        </motion.div>
      )}

      {/* Calculator & Energy Output Matrix */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Feedstock Input Form */}
        <Card className="lg:col-span-5 border-green-200 bg-white/90 dark:bg-zinc-900/90 shadow-md">
          <CardHeader>
            <CardTitle className="text-lg font-bold text-emerald-900 dark:text-emerald-100 flex items-center gap-2">
              <Flame className="h-5 w-5 text-emerald-600" /> Daily Feedstock Calculator
            </CardTitle>
            <CardDescription>Select feedstock type and operational inputs to calculate daily yield.</CardDescription>
          </CardHeader>
          <CardContent>
            <form onSubmit={handleLogSubmit} className="space-y-4">
              <div>
                <Label htmlFor="category">Feedstock Category</Label>
                <Select value={category} onValueChange={handleCategoryChange}>
                  <SelectTrigger className="mt-1 border-green-300 focus:ring-green-500">
                    <SelectValue placeholder="Select feedstock category" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="CATTLE_MANURE">Cattle Manure</SelectItem>
                    <SelectItem value="FOOD_WASTE">Food Waste</SelectItem>
                    <SelectItem value="CROP_RESIDUE">Crop Residue</SelectItem>
                    <SelectItem value="SEWAGE_SLUDGE">Sewage Sludge</SelectItem>
                    <SelectItem value="OTHER">Generic Organic Waste</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              <div>
                <Label htmlFor="weight">Input Mass (kg / day)</Label>
                <Input 
                  id="weight" type="number" min="0" value={weightKg} 
                  onChange={(e) => setWeightKg(Number(e.target.value))}
                  className="mt-1 border-green-300 focus:ring-green-500"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <Label htmlFor="ts">Total Solids (TS %)</Label>
                  <Input 
                    id="ts" type="number" min="0" max="100" step="0.1" value={tsPercent} 
                    onChange={(e) => setTsPercent(Number(e.target.value))}
                    className="mt-1 border-green-300 focus:ring-green-500"
                  />
                </div>
                <div>
                  <Label htmlFor="vs">Volatile Solids (VS %)</Label>
                  <Input 
                    id="vs" type="number" min="0" max="100" step="0.1" value={vsPercent} 
                    onChange={(e) => setVsPercent(Number(e.target.value))}
                    className="mt-1 border-green-300 focus:ring-green-500"
                  />
                </div>
              </div>

              <div>
                <Label htmlFor="methane">Expected Methane Content (CH₄ %)</Label>
                <Input 
                  id="methane" type="number" min="0" max="100" value={methanePercent} 
                  onChange={(e) => setMethanePercent(Number(e.target.value))}
                  className="mt-1 border-green-300 focus:ring-green-500"
                />
              </div>

              <Button type="submit" className="w-full bg-emerald-600 hover:bg-emerald-700 text-white font-semibold">
                <CheckCircle2 className="mr-2 h-4 w-4" /> Save Operational Daily Log
              </Button>
            </form>
          </CardContent>
        </Card>

        {/* Calculated Yield & Energy Equivalent Dashboard */}
        <Card className="lg:col-span-7 border-green-200 bg-gradient-to-br from-emerald-50/50 to-teal-50/30 dark:from-zinc-900 dark:to-zinc-950 shadow-md">
          <CardHeader>
            <CardTitle className="text-lg font-bold text-emerald-900 dark:text-emerald-100 flex items-center gap-2">
              <Zap className="h-5 w-5 text-amber-500" /> Biogas & Energy Yield Output
            </CardTitle>
            <CardDescription>Mathematical model prediction based on feedstock kinetics.</CardDescription>
          </CardHeader>
          <CardContent className="space-y-6">
            {yieldResult && (
              <>
                {/* Primary Metrics */}
                <div className="grid grid-cols-2 sm:grid-cols-3 gap-3">
                  <div className="bg-white dark:bg-zinc-800 p-3.5 rounded-xl border border-emerald-100 dark:border-zinc-700 shadow-sm">
                    <p className="text-xs text-muted-foreground">Biogas Produced</p>
                    <p className="text-2xl font-black text-emerald-700 dark:text-emerald-400 mt-1">
                      {yieldResult.yield.biogasProducedM3} <span className="text-sm font-semibold">m³</span>
                    </p>
                  </div>
                  <div className="bg-white dark:bg-zinc-800 p-3.5 rounded-xl border border-emerald-100 dark:border-zinc-700 shadow-sm">
                    <p className="text-xs text-muted-foreground">Methane Volume</p>
                    <p className="text-2xl font-black text-teal-700 dark:text-teal-400 mt-1">
                      {yieldResult.yield.methaneVolumeM3} <span className="text-sm font-semibold">m³ CH₄</span>
                    </p>
                  </div>
                  <div className="bg-white dark:bg-zinc-800 p-3.5 rounded-xl border border-emerald-100 dark:border-zinc-700 shadow-sm col-span-2 sm:col-span-1">
                    <p className="text-xs text-muted-foreground">Calculated HRT</p>
                    <p className="text-2xl font-black text-emerald-900 dark:text-emerald-100 mt-1">
                      {yieldResult.yield.calculatedHrtDays} <span className="text-sm font-semibold">days</span>
                    </p>
                  </div>
                </div>

                {/* Energy Equivalents Grid */}
                <div className="space-y-3">
                  <h4 className="text-xs font-bold uppercase tracking-wider text-emerald-800 dark:text-emerald-300">
                    Energy Equivalent Conversions
                  </h4>
                  <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                    <div className="flex items-center gap-3 p-3 bg-amber-500/10 border border-amber-500/20 rounded-xl">
                      <Zap className="h-8 w-8 text-amber-500 shrink-0" />
                      <div>
                        <p className="text-xs text-amber-900 dark:text-amber-200 font-medium">CHP Electricity</p>
                        <p className="text-lg font-bold text-amber-700 dark:text-amber-400">{yieldResult.energyOutput.electricityKwh} kWh</p>
                      </div>
                    </div>

                    <div className="flex items-center gap-3 p-3 bg-orange-500/10 border border-orange-500/20 rounded-xl">
                      <Flame className="h-8 w-8 text-orange-500 shrink-0" />
                      <div>
                        <p className="text-xs text-orange-900 dark:text-orange-200 font-medium">LPG Equivalent</p>
                        <p className="text-lg font-bold text-orange-700 dark:text-orange-400">{yieldResult.energyOutput.lpgEquivalentKg} kg</p>
                      </div>
                    </div>

                    <div className="flex items-center gap-3 p-3 bg-rose-500/10 border border-rose-500/20 rounded-xl">
                      <Activity className="h-8 w-8 text-rose-500 shrink-0" />
                      <div>
                        <p className="text-xs text-rose-900 dark:text-rose-200 font-medium">Heat Energy</p>
                        <p className="text-lg font-bold text-rose-700 dark:text-rose-400">{yieldResult.energyOutput.heatEnergyMj} MJ</p>
                      </div>
                    </div>
                  </div>
                </div>

                {/* Dry Basis & Volatile Solids Info */}
                <div className="bg-emerald-900/5 dark:bg-zinc-800/60 p-4 rounded-xl border border-emerald-200/60 text-xs space-y-1 text-emerald-900 dark:text-emerald-200">
                  <div className="flex justify-between">
                    <span>Dry Matter (Total Solids):</span>
                    <span className="font-mono font-bold">{yieldResult.yield.totalSolidsKg} kg</span>
                  </div>
                  <div className="flex justify-between">
                    <span>Volatile Solids (VS):</span>
                    <span className="font-mono font-bold">{yieldResult.yield.volatileSolidsKg} kg</span>
                  </div>
                </div>
              </>
            )}
          </CardContent>
        </Card>
      </div>

      {/* Interactive Technical Manual & Standard Operating Procedures (SOP) */}
      <Card className="border-emerald-200 bg-white/90 dark:bg-zinc-900/90 shadow-md">
        <CardHeader>
          <CardTitle className="text-lg font-bold text-emerald-900 dark:text-emerald-100 flex items-center gap-2">
            <BookOpen className="h-5 w-5 text-emerald-600" /> Biogas Plant Standard Operating Manual & Guidelines
          </CardTitle>
          <CardDescription>Reference manual for plant operators, engineers, and safety technicians.</CardDescription>
        </CardHeader>
        <CardContent>
          <Tabs value={manualTab} onValueChange={setManualTab} className="w-full">
            <TabsList className="grid w-full grid-cols-3 bg-emerald-50 dark:bg-zinc-800">
              <TabsTrigger value="sop" className="text-xs font-semibold">Standard Operating Procedures</TabsTrigger>
              <TabsTrigger value="trouble" className="text-xs font-semibold">Troubleshooting & Safety</TabsTrigger>
              <TabsTrigger value="formulas" className="text-xs font-semibold">Mathematical Models</TabsTrigger>
            </TabsList>

            <TabsContent value="sop" className="mt-4 space-y-3 text-sm text-zinc-700 dark:text-zinc-300">
              <div className="p-4 rounded-xl bg-emerald-50/50 dark:bg-zinc-800/50 border border-emerald-100 space-y-2">
                <h4 className="font-bold text-emerald-900 dark:text-emerald-200 flex items-center gap-1.5">
                  <ShieldCheck className="h-4 w-4 text-emerald-600" /> Daily Feeding & Substrate Homogenization Protocol
                </h4>
                <p className="text-xs leading-relaxed">
                  Feedstock should be shredded and mixed with water to achieve a slurry Total Solids (TS) concentration between <strong>8% and 12%</strong>. Ensure volatile solids input is logged daily to prevent digester overload. Maintain Hydraulic Retention Time (HRT) between 20 and 40 days.
                </p>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-3 gap-3 text-xs">
                <div className="p-3 rounded-lg border border-zinc-200 dark:border-zinc-700 bg-white dark:bg-zinc-800">
                  <p className="font-bold text-emerald-700 dark:text-emerald-400">Step 1: Feed Pre-treatment</p>
                  <p className="mt-1 text-zinc-600 dark:text-zinc-400">Macerate fibrous substrate to &lt;10mm particle size for optimal methanogen surface area.</p>
                </div>
                <div className="p-3 rounded-lg border border-zinc-200 dark:border-zinc-700 bg-white dark:bg-zinc-800">
                  <p className="font-bold text-emerald-700 dark:text-emerald-400">Step 2: Temperature Control</p>
                  <p className="mt-1 text-zinc-600 dark:text-zinc-400">Maintain mesophilic zone (35-37°C) within ±0.5°C to avoid methanogenic thermal shock.</p>
                </div>
                <div className="p-3 rounded-lg border border-zinc-200 dark:border-zinc-700 bg-white dark:bg-zinc-800">
                  <p className="font-bold text-emerald-700 dark:text-emerald-400">Step 3: Gas Scrubbing</p>
                  <p className="mt-1 text-zinc-600 dark:text-zinc-400">Pass raw biogas through iron sponge / biological desulfurization to maintain H₂S &lt; 200 ppm.</p>
                </div>
              </div>
            </TabsContent>

            <TabsContent value="trouble" className="mt-4 space-y-3 text-sm">
              <div className="p-4 rounded-xl bg-red-50 dark:bg-red-950/40 border border-red-200 text-red-900 dark:text-red-200 space-y-1.5">
                <h4 className="font-bold text-sm flex items-center gap-1.5">
                  <Wrench className="h-4 w-4 text-red-600" /> Acidification Intervention Protocol (pH &lt; 6.5)
                </h4>
                <p className="text-xs leading-relaxed">
                  Volatile Fatty Acid (VFA) accumulation indicates acidogen over-activity relative to methanogens. 
                  <strong> Action:</strong> Immediately halt organic loading. Douse digester with Sodium Bicarbonate (NaHCO₃) or Lime slurry until pH recovers to 7.0.
                </p>
              </div>

              <div className="p-4 rounded-xl bg-amber-50 dark:bg-amber-950/40 border border-amber-200 text-amber-900 dark:text-amber-200 space-y-1.5">
                <h4 className="font-bold text-sm flex items-center gap-1.5">
                  <ShieldAlert className="h-4 w-4 text-amber-600" /> Pressure Leak & Foam Overflow Containment
                </h4>
                <p className="text-xs leading-relaxed">
                  If internal pressure drops to 0 bar, inspect gas storage dome seals. If foaming occurs, add food-grade vegetable oil antifoam agent via the secondary feeding line.
                </p>
              </div>
            </TabsContent>

            <TabsContent value="formulas" className="mt-4 space-y-3 text-xs font-mono text-zinc-800 dark:text-zinc-200">
              <div className="p-4 rounded-xl bg-zinc-50 dark:bg-zinc-800/80 border border-zinc-200 dark:border-zinc-700 space-y-2">
                <p className="font-bold text-emerald-800 dark:text-emerald-300 font-sans text-sm">Kinetic Kinetic & Energy Yield Formulas</p>
                <div className="bg-white dark:bg-zinc-900 p-3 rounded-lg border text-[11px] space-y-1 overflow-x-auto">
                  <p>1. Volatile Solids Mass: VS_kg = Feed_Weight * (TS%/100) * (VS%/100)</p>
                  <p>2. Daily Biogas Volume: Biogas_m3 = VS_kg * Specific_Yield_Rate (m3/kg VS)</p>
                  <p>3. Methane Volume: CH4_m3 = Biogas_m3 * (CH4%/100)</p>
                  <p>4. CHP Electricity: kWh = CH4_m3 * 9.94 kWh/m3 * 0.35 (Efficiency)</p>
                  <p>5. LPG Mass Equivalent: LPG_kg = (CH4_m3 * 35.80 MJ/m3) / 46.10 MJ/kg</p>
                </div>
              </div>
            </TabsContent>
          </Tabs>
        </CardContent>
      </Card>

      {/* Operational Logs History Table */}
      <Card className="border-green-200 bg-white/90 dark:bg-zinc-900/90 shadow-md">
        <CardHeader>
          <CardTitle className="text-lg font-bold text-emerald-900 dark:text-emerald-100 flex items-center justify-between">
            <span>Recent Operational Feeding Logs</span>
            <Badge variant="outline" className="font-normal">{logs.length} Entries</Badge>
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="overflow-x-auto">
            <table className="w-full text-left text-sm">
              <thead className="bg-emerald-50 dark:bg-zinc-800 text-xs font-semibold text-emerald-900 dark:text-emerald-200 uppercase">
                <tr>
                  <th className="p-3">Timestamp</th>
                  <th className="p-3">Category</th>
                  <th className="p-3">Weight (kg)</th>
                  <th className="p-3">Biogas (m³)</th>
                  <th className="p-3">Electricity (kWh)</th>
                  <th className="p-3">pH / Temp</th>
                  <th className="p-3">Status</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-zinc-200 dark:divide-zinc-800">
                {logs.map((item) => (
                  <tr key={item.id} className="hover:bg-emerald-50/50 dark:hover:bg-zinc-800/50 transition">
                    <td className="p-3 font-mono text-xs">{item.date}</td>
                    <td className="p-3 font-medium">{item.category.replace('_', ' ')}</td>
                    <td className="p-3">{item.weightKg} kg</td>
                    <td className="p-3 font-bold text-emerald-700 dark:text-emerald-400">{item.biogasM3} m³</td>
                    <td className="p-3 text-amber-600 font-semibold">{item.electricityKwh} kWh</td>
                    <td className="p-3 text-xs">{item.ph} pH / {item.temp}°C</td>
                    <td className="p-3">
                      <Badge className={item.status === 'HEALTHY' ? 'bg-emerald-600' : 'bg-amber-500'}>
                        {item.status}
                      </Badge>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
