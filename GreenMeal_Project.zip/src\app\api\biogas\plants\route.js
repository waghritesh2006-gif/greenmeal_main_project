import { NextResponse } from 'next/server';
import { BiogasPlantSchema } from '@/lib/validations/biogasSchemas';

// In-memory persistent mock store for demonstration & API functionality
let biogasPlantsStore = [
  {
    id: 'plant-001',
    name: 'GreenMeal Anaerobic Digester #1',
    location: 'Sector 4 Eco Campus',
    digesterCapacityM3: 250,
    maxGasStorageM3: 500,
    targetHrtDays: 30,
    minIdealPh: 6.8,
    maxIdealPh: 7.5,
    minIdealTempC: 35.0,
    maxIdealTempC: 55.0,
    createdAt: new Date().toISOString(),
  },
];

export async function GET() {
  return NextResponse.json({
    success: true,
    data: biogasPlantsStore,
  });
}

export async function POST(req) {
  try {
    const body = await req.json();
    const validationResult = BiogasPlantSchema.safeParse(body);

    if (!validationResult.success) {
      return NextResponse.json({
        success: false,
        error: 'Validation Error',
        details: validationResult.error.flatten().fieldErrors,
      }, { status: 400 });
    }

    const newPlant = {
      id: `plant-${Date.now()}`,
      ...validationResult.data,
      createdAt: new Date().toISOString(),
    };

    biogasPlantsStore.push(newPlant);

    return NextResponse.json({
      success: true,
      message: 'Biogas Plant registered successfully',
      data: newPlant,
    }, { status: 201 });
  } catch (error) {
    return NextResponse.json({
      success: false,
      error: 'Internal Server Error',
      message: error.message,
    }, { status: 500 });
  }
}
