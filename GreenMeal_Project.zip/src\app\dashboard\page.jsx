'use client'

import { useState, useEffect } from 'react'
import dynamic from 'next/dynamic'
import { motion, AnimatePresence } from 'framer-motion'
import Sidebar from '@/components/User/Sidebar'
import Header from '@/components/User/Header'
import Overview from '@/components/User/Overview'
import Inventory from '@/components/User/Inventory'
import BiogasModule from '@/components/User/BiogasModule'
import CompostModule from '@/components/User/CompostModule'
import Account from '@/components/User/Account'
import NGO from '@/components/User/NGO'
import History from '@/components/User/History'
import UpcomingEvent from '@/components/User/UpcomingEvent'
import { checkToken } from '@/utils/checkAuth'

// Dynamically import Recipes with ssr: false to prevent browser extension (fdprocessedid) hydration overlays
const Recipes = dynamic(() => import('@/components/User/Recipes'), { 
  ssr: false,
  loading: () => (
    <div className="flex h-[calc(100vh-140px)] items-center justify-center bg-white dark:bg-zinc-900 rounded-2xl border border-green-200 text-emerald-800 dark:text-emerald-200">
      <div className="flex items-center gap-2 font-semibold text-sm">
        <div className="h-5 w-5 animate-spin rounded-full border-2 border-emerald-600 border-t-transparent" />
        Loading Recipes Assistant...
      </div>
    </div>
  )
})

const searchData = [
  { title: 'Overview', component: 'Overview' },
  { title: 'Inventory', component: 'Inventory' },
  { title: 'Biogas Plant Management', component: 'BiogasModule' },
  { title: 'Compost Lifecycle Tracker', component: 'CompostModule' },
  { title: 'Recipes', component: 'Recipes' },
  { title: 'NGO Partnerships', component: 'NGO' },
  { title: 'Donation History', component: 'History' },
  { title: 'Account Settings', component: 'Account' },
]

export default function DashboardLayout() {
  const [isSidebarOpen, setIsSidebarOpen] = useState(false)
  const [selectedComponent, setSelectedComponent] = useState('Overview')
  const [searchQuery, setSearchQuery] = useState('')
  const [searchResults, setSearchResults] = useState([])
  const [isSettingsOpen, setIsSettingsOpen] = useState(false)
  const [userData, setUserData] = useState({})

  const toggleSidebar = () => setIsSidebarOpen(!isSidebarOpen)

  useEffect(() => {
    const verifyToken = async () => {
      const tokenValid = await checkToken()
      if (tokenValid?.data) {
        setUserData(tokenValid.data)
      }
    }
    verifyToken()

    const handleResize = () => {
      if (window.innerWidth >= 768) {
        setIsSidebarOpen(true)
      } else {
        setIsSidebarOpen(false)
      }
    }

    window.addEventListener('resize', handleResize)
    handleResize()

    return () => window.removeEventListener('resize', handleResize)
  }, [])

  useEffect(() => {
    if (searchQuery) {
      const results = searchData.filter(item =>
        item.title.toLowerCase().includes(searchQuery.toLowerCase())
      )
      setSearchResults(results)
    } else {
      setSearchResults([])
    }
  }, [searchQuery])

  const handleSearchSelect = (component) => {
    setSelectedComponent(component)
    setSearchQuery('')
  }

  const renderComponent = () => {
    switch (selectedComponent) {
      case 'Overview':
        return <Overview />
      case 'Inventory':
        return <Inventory userData={userData} />
      case 'BiogasModule':
        return <BiogasModule />
      case 'CompostModule':
        return <CompostModule />
      case 'Recipes':
        return <Recipes />
      case 'NGO':
        return <NGO userData={userData} />
      case 'History':
        return <History userData={userData} />
      case 'UpcomingEvent':
        return <UpcomingEvent />
      case 'Account':
        return <Account userData={userData} />
      default:
        return <Overview />
    }
  }

  return (
    <div className="flex h-screen bg-green-50 dark:bg-zinc-950 text-green-900 dark:text-green-100 transition-colors">
      <AnimatePresence>
        {isSidebarOpen && (
          <motion.div
            initial={{ x: -300 }}
            animate={{ x: 0 }}
            exit={{ x: -300 }}
            transition={{ type: 'spring', stiffness: 300, damping: 30 }}
            className="fixed inset-y-0 left-0 z-50 w-64 bg-green-100 dark:bg-zinc-900 shadow-lg md:relative"
          >
            <Sidebar 
              onSelectComponent={setSelectedComponent} 
              closeSidebar={() => setIsSidebarOpen(false)}
              onOpenSettings={() => setIsSettingsOpen(true)}
            />
          </motion.div>
        )}
      </AnimatePresence>
      <div className="flex-1 flex flex-col overflow-hidden">
        <Header 
          isSidebarOpen={isSidebarOpen}
          toggleSidebar={toggleSidebar}
          selectedComponent={selectedComponent}
          searchQuery={searchQuery}
          setSearchQuery={setSearchQuery}
          searchResults={searchResults}
          handleSearchSelect={handleSearchSelect}
          isSettingsOpen={isSettingsOpen}
          setIsSettingsOpen={setIsSettingsOpen}
        />
        <main className="flex-1 overflow-x-hidden overflow-y-auto bg-green-50/70 dark:bg-zinc-950 p-6 transition-colors">
          <motion.div
            key={selectedComponent}
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -10 }}
            transition={{ duration: 0.2 }}
          >
            {renderComponent()}
          </motion.div>
        </main>
      </div>
    </div>
  )
}