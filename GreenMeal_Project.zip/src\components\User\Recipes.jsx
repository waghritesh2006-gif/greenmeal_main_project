'use client';

import { useState } from 'react';
import GroceryList from './GroceryList';
import RecipeChatbot from './RecipeChatbot';

export default function Recipes() {
  const [selectedIngredients, setSelectedIngredients] = useState([]);

  const handleIngredientSelect = (ingredients) => {
    setSelectedIngredients(ingredients);
  };

  return (
    <div className="flex flex-col lg:flex-row h-[calc(100vh-130px)] gap-6 pb-2">
      {/* Left Column: Grocery List Selector */}
      <div className="w-full lg:w-96 shrink-0 h-full">
        <GroceryList onIngredientSelect={handleIngredientSelect} />
      </div>
      
      {/* Right Column: Interactive AI Recipe Chatbot */}
      <div className="w-full flex-1 h-full min-h-[500px]">
        <RecipeChatbot selectedIngredients={selectedIngredients} />
      </div>
    </div>
  );
}