'use client'

import { useEffect, useState } from 'react'
import { motion } from 'framer-motion'
import { Card, CardContent, CardHeader, CardTitle, CardFooter } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Edit, Trash2, Award, Mail, Phone, MapPin, Globe, Check, Save } from 'lucide-react'
import { toast } from 'sonner'
import { BaseApiUrl } from '@/utils/constanst'

export default function UserProfile({ userData }) {
  const [isEditing, setIsEditing] = useState(true)
  const [profile, setProfile] = useState({
    firstName: "Ritesh",
    lastName: "Wagh",
    userName: "Ritesh Wagh",
    email: "ritesh.wagh@greenmeal.org",
    phone: "+91 9876543210",
    address: "123 Green Street, Eco City, Mumbai 400001",
    language: "English",
    profilePic: "/placeholder.svg?height=200&width=200",
    certificates: [
      { id: 1, name: "Eco Warrior Certificate", date: "2023-05-15", recipient: "Ritesh Wagh" },
      { id: 2, name: "Green Sustainability Champion", date: "2023-06-20", recipient: "Soham Rane" },
    ]
  })

  useEffect(() => {
    const fetchUser = async () => {
      try {
        if (!userData?.user?.id) return;
        const response = await fetch(`${BaseApiUrl}/user/user`, {
          method: 'get',
          headers: {
            'Content-Type': 'application/json',
            'id': userData.user.id
          },
        })
        const json = await response.json()
        if (json?.resume) {
          setProfile(prev => ({
            ...prev,
            userName: json.resume.userName || prev.userName,
            firstName: json.resume.userName ? json.resume.userName.split(' ')[0] : prev.firstName,
            lastName: json.resume.userName ? json.resume.userName.split(' ').slice(1).join(' ') : prev.lastName,
            email: json.resume.email || prev.email,
            phone: json.resume.phone || prev.phone,
            address: json.resume.address || prev.address
          }))
        }
      } catch (error) {
        console.warn('Account fetchUser warning:', error.message)
      }
    }
    fetchUser()
  }, [userData?.user?.id])

  const handleInputChange = (field, value) => {
    setProfile(prev => ({
      ...prev,
      [field]: value
    }))
  }

  const handleSave = () => {
    setIsEditing(false)
    toast.success("Profile details saved successfully!")
  }

  const handleEditToggle = () => {
    setIsEditing(!isEditing)
  }

  return (
    <div className="container mx-auto p-4 bg-gradient-to-b from-green-50 to-green-100 dark:from-zinc-950 dark:to-zinc-900 rounded-2xl min-h-screen">
      <motion.h1
        initial={{ opacity: 0, y: -20 }}
        animate={{ opacity: 1, y: 0 }}
        className="text-4xl font-bold text-green-800 dark:text-green-200 mb-8 text-center"
      >
        User Account & Profile Settings
      </motion.h1>

      <Card className="bg-white dark:bg-zinc-900 border-green-200 dark:border-zinc-800 shadow-xl rounded-2xl overflow-hidden max-w-4xl mx-auto">
        <CardHeader className="bg-gradient-to-r from-emerald-700 to-teal-800 text-white p-6">
          <div className="flex flex-col md:flex-row items-center space-y-4 md:space-y-0 md:space-x-6">
            <Avatar className="w-24 h-24 border-4 border-white shadow-lg">
              <AvatarImage src={profile.profilePic} alt={profile.userName} />
              <AvatarFallback className="text-3xl font-bold bg-emerald-500 text-white">
                {profile.userName ? profile.userName[0] : 'R'}
              </AvatarFallback>
            </Avatar>

            <div className="text-center md:text-left flex-1 space-y-2">
              <div className="space-y-1">
                <Label className="text-emerald-200 text-xs font-semibold">Full Name / Display Name</Label>
                <Input
                  value={profile.userName}
                  onChange={(e) => {
                    const val = e.target.value;
                    handleInputChange('userName', val);
                    handleInputChange('firstName', val.split(' ')[0] || '');
                    handleInputChange('lastName', val.split(' ').slice(1).join(' ') || '');
                  }}
                  className="bg-white/20 text-white placeholder-emerald-200 border-emerald-400 font-bold text-xl h-10 rounded-xl"
                  placeholder="Enter full name"
                />
              </div>
              <p className="text-emerald-100 text-xs font-mono">{profile.email}</p>
            </div>
          </div>
        </CardHeader>

        <CardContent className="p-6">
          <Tabs defaultValue="info" className="w-full">
            <TabsList className="grid w-full grid-cols-2 mb-6 bg-green-50 dark:bg-zinc-800 p-1 rounded-xl">
              <TabsTrigger value="info" className="font-semibold text-xs py-2">Editable Personal Details</TabsTrigger>
              <TabsTrigger value="certificates" className="font-semibold text-xs py-2">Issued Certificates</TabsTrigger>
            </TabsList>

            <TabsContent value="info">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div className="space-y-2">
                  <Label htmlFor="email" className="flex items-center text-green-800 dark:text-green-300 font-semibold text-xs">
                    <Mail className="mr-2 h-4 w-4 text-emerald-600" /> Email Address
                  </Label>
                  <Input
                    id="email"
                    type="email"
                    value={profile.email}
                    onChange={(e) => handleInputChange('email', e.target.value)}
                    className="border-green-300 dark:border-zinc-700 focus:ring-emerald-500 rounded-xl text-xs"
                    placeholder="Enter email address"
                  />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="phone" className="flex items-center text-green-800 dark:text-green-300 font-semibold text-xs">
                    <Phone className="mr-2 h-4 w-4 text-emerald-600" /> Phone Number
                  </Label>
                  <Input
                    id="phone"
                    type="text"
                    value={profile.phone}
                    onChange={(e) => handleInputChange('phone', e.target.value)}
                    className="border-green-300 dark:border-zinc-700 focus:ring-emerald-500 rounded-xl text-xs"
                    placeholder="Enter phone number"
                  />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="address" className="flex items-center text-green-800 dark:text-green-300 font-semibold text-xs">
                    <MapPin className="mr-2 h-4 w-4 text-emerald-600" /> Address & Location
                  </Label>
                  <Input
                    id="address"
                    type="text"
                    value={profile.address}
                    onChange={(e) => handleInputChange('address', e.target.value)}
                    className="border-green-300 dark:border-zinc-700 focus:ring-emerald-500 rounded-xl text-xs"
                    placeholder="Enter street address & city"
                  />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="language" className="flex items-center text-green-800 dark:text-green-300 font-semibold text-xs">
                    <Globe className="mr-2 h-4 w-4 text-emerald-600" /> Preferred Language
                  </Label>
                  <Select
                    value={profile.language}
                    onValueChange={(val) => handleInputChange('language', val)}
                  >
                    <SelectTrigger className="border-green-300 dark:border-zinc-700 rounded-xl text-xs">
                      <SelectValue placeholder="Select Language" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="English">English</SelectItem>
                      <SelectItem value="Hindi">Hindi</SelectItem>
                      <SelectItem value="Marathi">Marathi</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>
            </TabsContent>

            <TabsContent value="certificates">
              <div className="space-y-4">
                <h3 className="text-base font-bold text-green-800 dark:text-green-300 flex items-center gap-2">
                  <Award className="h-5 w-5 text-emerald-600" /> Your Achieved Certificates
                </h3>
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>Certificate Title</TableHead>
                      <TableHead>Issued To</TableHead>
                      <TableHead>Date Issued</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {profile.certificates.map((cert) => (
                      <TableRow key={cert.id}>
                        <TableCell className="font-semibold text-zinc-900 dark:text-zinc-100">{cert.name}</TableCell>
                        <TableCell className="font-bold text-emerald-700 dark:text-emerald-400">{cert.recipient}</TableCell>
                        <TableCell className="text-xs text-zinc-500">{cert.date}</TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </div>
            </TabsContent>
          </Tabs>
        </CardContent>

        <CardFooter className="bg-green-50 dark:bg-zinc-800/50 p-6 flex justify-between items-center">
          <Button onClick={handleSave} className="bg-emerald-600 hover:bg-emerald-700 text-white font-semibold rounded-xl text-xs px-6 py-5">
            <Save className="mr-2 h-4 w-4" /> Save Profile Details
          </Button>
          <span className="text-xs text-zinc-400 font-mono">Status: Profile Active & Editable</span>
        </CardFooter>
      </Card>
    </div>
  )
}