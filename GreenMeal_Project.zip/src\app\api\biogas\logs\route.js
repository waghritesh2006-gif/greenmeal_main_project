import { NextResponse } from 'next/server';
import { BiogasLogSchema } from '@/lib/validations/biogasSchemas';
import { calculateBiogasYield, evaluateDigesterHealth } from '@/lib/services/biogasEngine';

let biogasLogsStore = [];

export async function GET(req) {
  const { searchParams } = new URL(req.url);
  const plantId = searchParams.get('plantId');

  let logs = biogasLogsStore;
  if (plantId) {
    logs = logs.filter(log => log.plantId === plantId);
  }

  return NextResponse.json({
    success: true,
    count: logs.length,
    data: logs,
  });
}

export async function POST(req) {
  try {
    const body = await req.json();
    const validationResult = BiogasLogSchema.safeParse(body);

    if (!validationResult.success) {
      return NextResponse.json({
        success: false,
        error: 'Validation Error',
        details: validationResult.error.flatten().fieldErrors,
      }, { status: 400 });
    }

    const logData = validationResult.data;

    // 1. Run Mathematical Engine for Biogas & Energy Yield
    const yieldCalculations = calculateBiogasYield({
      feedstockCategory: logData.feedstockCategory,
      feedstockWeightKg: logData.feedstockWeightKg,
      tsPercent: logData.tsPercent,
      vsPercent: logData.vsPercent,
      biogasYieldPerKgVs: logData.biogasYieldPerKgVs,
      methaneContentPercent: logData.methaneContentPercent,
      digesterCapacityM3: logData.digesterCapacityM3,
    });

    // 2. Evaluate Digester Health & Trigger Failure Risk Alerts
    const healthReport = evaluateDigesterHealth({
      phLevel: logData.phLevel,
      temperatureC: logData.temperatureC,
      pressureBar: logData.pressureBar,
    }, logData.currentStorageLevelM3, logData.digesterCapacityM3 * 2);

    const newLogRecord = {
      id: `log-${Date.now()}`,
      plantId: logData.plantId,
      feedstockCategory: logData.feedstockCategory,
      feedstockWeightKg: logData.feedstockWeightKg,
      telemetry: {
        temperatureC: logData.temperatureC,
        phLevel: logData.phLevel,
        pressureBar: logData.pressureBar,
        currentStorageLevelM3: logData.currentStorageLevelM3,
      },
      gasUsage: {
        gasFlaredM3: logData.gasFlaredM3,
        gasUsedM3: logData.gasUsedM3,
      },
      yieldOutput: yieldCalculations.yield,
      energyOutput: yieldCalculations.energyOutput,
      healthReport,
      loggedAt: new Date().toISOString(),
    };

    biogasLogsStore.push(newLogRecord);

    return NextResponse.json({
      success: true,
      message: 'Operational feeding and telemetry logged successfully',
      data: newLogRecord,
    }, { status: 201 });
  } catch (error) {
    return NextResponse.json({
      success: false,
      error: 'Internal Server Error',
      message: error.message,
    }, { status: 500 });
  }
}
