'use client'

import React, { useState, useEffect } from 'react'
import { motion, AnimatePresence } from 'framer-motion'
import { Card, CardContent, CardHeader, CardTitle, CardFooter } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Badge } from "@/components/ui/badge"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog"
import { Leaf, Search, Calendar, Package, CheckCircle2, Truck, Box, Loader2 } from 'lucide-react'
import CertificateComponent from '../Admin/CertificateComponent'

const dummyDonations = [
  { 
    id: 1, 
    ngo: "Green Earth Foundation", 
    items: ["Surplus Rice", "Organic Pulses"], 
    date: "2023-06-15", 
    status: "complete",
    donor: "Ritesh Wagh",
    location: "Mumbai",
    updates: [
      { status: "Donation Initiated", date: "2023-06-15", icon: Box, completed: true },
      { status: "Picked up", date: "2023-06-16", icon: Truck, completed: true },
      { status: "In Transit", date: "2023-06-16", icon: Truck, completed: true },
      { status: "Delivered", date: "2023-06-17", icon: CheckCircle2, completed: true },
    ]
  },
  { 
    id: 2, 
    ngo: "Clean Water Initiative", 
    items: ["Water Purifier Kit"], 
    date: "2023-06-20", 
    status: "pending",
    donor: "Soham Rane",
    location: "Mumbai",
    updates: [
      { status: "Donation Initiated", date: "2023-06-20", icon: Box, completed: true },
      { status: "Awaiting pickup", date: "2023-06-21", icon: Truck, completed: false },
      { status: "In Transit", date: "", icon: Truck, completed: false },
      { status: "Delivered", date: "", icon: CheckCircle2, completed: false },
    ]
  },
]

export default function DonationHistory({ userData }) {
  const [donations, setDonations] = useState(dummyDonations)
  const [searchTerm, setSearchTerm] = useState('')
  const [statusFilter, setStatusFilter] = useState('all')
  const [selectedDonation, setSelectedDonation] = useState(null)
  const [isCertificateOpen, setIsCertificateOpen] = useState(false)
  const [isLoading, setIsLoading] = useState(false)

  useEffect(() => {
    const fetchhistory = async () => {
      try {
        if (!userData?.user?.id) return;
        const response3 = await fetch(`http://localhost:4000/api/history`, {
          method: 'get',
          headers: {
            'Content-Type': 'application/json',
            'id': userData.user.id
          }
        })
        const json3 = await response3.json()
        if (json3?.resume && json3.resume.length > 0) {
          // Keep donors Ritesh Wagh and Soham Rane for the certificates
          const updated = json3.resume.map((item, idx) => ({
            ...item,
            donor: idx === 0 ? "Ritesh Wagh" : (idx === 1 ? "Soham Rane" : (item.donor || "Ritesh Wagh"))
          }));
          setDonations(updated)
        }
      } catch (error) {
        console.warn('History API offline, using fallback records:', error)
      }
    }
    fetchhistory()
  }, [userData?.user?.id])

  const handleSearch = (event) => {
    setSearchTerm(event.target.value.toLowerCase())
  }

  const handleStatusFilter = (value) => {
    setStatusFilter(value)
  }

  const filteredDonations = donations.filter(donation => 
    (donation.ngo.toLowerCase().includes(searchTerm) || 
     donation.items.some(item => item.toLowerCase().includes(searchTerm)) ||
     (donation.donor && donation.donor.toLowerCase().includes(searchTerm))) &&
    (statusFilter === 'all' || donation.status === statusFilter)
  )

  const handleViewMore = (donation) => {
    setSelectedDonation(donation)
  }

  const handleGetCertificate = (donation) => {
    setSelectedDonation(donation)
    setIsCertificateOpen(true)
  }

  const handleCloseCertificate = () => {
    setIsCertificateOpen(false)
  }

  return (
    <div className="container mx-auto p-4 bg-gradient-to-b from-green-50 to-green-100 dark:from-zinc-950 dark:to-zinc-900 rounded-2xl min-h-screen">
      <motion.h1 
        initial={{ opacity: 0, y: -20 }}
        animate={{ opacity: 1, y: 0 }}
        className="text-4xl font-bold text-green-800 dark:text-green-200 mb-8 text-center"
      >
        Donation History & Certificates
      </motion.h1>

      <div className="flex flex-col sm:flex-row gap-4 mb-8">
        <div className="relative flex-grow">
          <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400" />
          <Input
            type="text"
            placeholder="Search by NGO, item, or certificate name..."
            value={searchTerm}
            onChange={handleSearch}
            className="pl-10 bg-white dark:bg-zinc-900 border-green-300 dark:border-zinc-700 focus:border-green-500 focus:ring-green-500 rounded-full"
          />
        </div>
        <Select onValueChange={handleStatusFilter} defaultValue="all">
          <SelectTrigger className="w-full sm:w-[180px] bg-white dark:bg-zinc-900 border-green-300 dark:border-zinc-700 focus:border-green-500 focus:ring-green-500 rounded-full">
            <SelectValue placeholder="Filter by status" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="all">All Status</SelectItem>
            <SelectItem value="pending">Pending</SelectItem>
            <SelectItem value="complete">Complete</SelectItem>
          </SelectContent>
        </Select>
      </div>

      {isLoading ? (
        <div className="flex justify-center items-center h-64">
          <Loader2 className="w-8 h-8 animate-spin text-green-600" />
        </div>
      ) : (
        <motion.div 
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ staggerChildren: 0.1 }}
          className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6"
        >
          <AnimatePresence>
            {filteredDonations.map((donation) => (
              <motion.div
                key={donation.id}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: -20 }}
                transition={{ duration: 0.3 }}
              >
                <Card className="bg-white dark:bg-zinc-900 border-green-200 dark:border-zinc-800 hover:shadow-lg transition-shadow rounded-xl overflow-hidden">
                  <CardHeader className="bg-green-600 text-white p-4">
                    <CardTitle className="flex items-center justify-between">
                      <div className="flex items-center">
                        <Leaf className="mr-2" size={18} />
                        <span className="text-lg font-semibold">{donation.ngo}</span>
                      </div>
                      <Badge 
                        variant={donation.status === 'complete' ? 'default' : 'secondary'}
                        className={`${donation.status === 'complete' ? 'bg-green-500' : 'bg-amber-500'} text-white`}
                      >
                        {donation.status}
                      </Badge>
                    </CardTitle>
                  </CardHeader>

                  <CardContent className="p-4 space-y-2">
                    <p className="flex items-center text-zinc-600 dark:text-zinc-300 text-sm">
                      <Calendar className="mr-2 text-green-500 flex-shrink-0" size={18} />
                      <span>{donation.date}</span>
                    </p>
                    <p className="flex items-start text-zinc-600 dark:text-zinc-300 text-sm">
                      <Package className="mr-2 text-green-500 flex-shrink-0 mt-0.5" size={18} />
                      <span>{donation.items.join(', ')}</span>
                    </p>
                    <p className="text-xs font-semibold text-emerald-700 dark:text-emerald-300 pt-1">
                      Certificate Issued To: <span className="font-bold underline">{donation.donor}</span>
                    </p>
                  </CardContent>

                  <CardFooter className="bg-green-50 dark:bg-zinc-800/50 p-4 flex justify-between">
                    <Dialog>
                      <DialogTrigger asChild>
                        <Button variant="outline" className="text-green-600 border-green-600 hover:bg-green-100 dark:hover:bg-zinc-800" onClick={() => handleViewMore(donation)}>
                          View More
                        </Button>
                      </DialogTrigger>
                      <DialogContent className="sm:max-w-[425px]">
                        <DialogHeader>
                          <DialogTitle className="text-green-700">Donation Updates</DialogTitle>
                        </DialogHeader>
                        <div className="mt-4 relative">
                          {donation.updates && donation.updates.map((update, index) => (
                            <div key={index} className="flex items-start mb-8 relative">
                              <div className={`absolute left-3 top-0 bottom-0 w-0.5 bg-green-200 ${index === donation.updates.length - 1 ? 'h-1/2' : ''}`}></div>
                              <div className={`flex items-center justify-center w-7 h-7 rounded-full ${update.completed ? 'bg-green-500' : 'bg-gray-300'} mr-4 z-10`}>
                                {update.icon && <update.icon className="w-4 h-4 text-white" />}
                              </div>
                              <div>
                                <p className={`font-semibold ${update.completed ? 'text-green-700' : 'text-gray-500'}`}>{update.status}</p>
                                <p className="text-sm text-gray-500">{update.date || 'Pending'}</p>
                              </div>
                            </div>
                          ))}
                        </div>
                      </DialogContent>
                    </Dialog>
                    <Button 
                      variant="secondary"
                      className="bg-green-600 text-white hover:bg-green-700"
                      onClick={() => handleGetCertificate(donation)}
                    >
                      Get Certificate
                    </Button>
                  </CardFooter>
                </Card>
              </motion.div>
            ))}
          </AnimatePresence>
        </motion.div>
      )}

      {!isLoading && filteredDonations.length === 0 && (
        <motion.p
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          className="text-center text-gray-500 mt-8"
        >
          No donations found matching your search criteria.
        </motion.p>
      )}

      <Dialog open={isCertificateOpen} onOpenChange={setIsCertificateOpen}>
        <DialogContent className="max-w-4xl">
          <DialogHeader>
            <DialogTitle className="text-green-700">Donation Certificate</DialogTitle>
          </DialogHeader>
          {selectedDonation && (
            <CertificateComponent
              donation={{
                ...selectedDonation,
                ngoName: selectedDonation.ngo,
              }}
              onClose={handleCloseCertificate}
              dataDonor={{ userName: selectedDonation.donor }}
            />
          )}
        </DialogContent>
      </Dialog>
    </div>
  )
}