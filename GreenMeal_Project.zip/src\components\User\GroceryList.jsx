'use client';

import { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { ScrollArea } from '@/components/ui/scroll-area';
import { ShoppingBasket, Leaf, Check } from 'lucide-react';

const groceryItems = [
  { id: 1, name: 'Tomatoes', expiryDate: '2026-09-05', category: 'Vegetables' },
  { id: 2, name: 'Chicken Breast', expiryDate: '2026-09-03', category: 'Meat' },
  { id: 3, name: 'Organic Rice', expiryDate: '2026-10-15', category: 'Grains' },
  { id: 4, name: 'Farm Eggs', expiryDate: '2026-09-10', category: 'Dairy' },
  { id: 5, name: 'Whole Grain Bread', expiryDate: '2026-09-04', category: 'Bakery' },
  { id: 6, name: 'Fresh Apples', expiryDate: '2026-09-12', category: 'Fruits' },
  { id: 7, name: 'Organic Carrots', expiryDate: '2026-09-08', category: 'Vegetables' },
];

export default function GroceryList({ onIngredientSelect }) {
  const [selectedItems, setSelectedItems] = useState([]);

  const toggleItemSelection = (item) => {
    setSelectedItems(prev =>
      prev.some(i => i.id === item.id)
        ? prev.filter(i => i.id !== item.id)
        : [...prev, item]
    );
  };

  const handleSendToChat = () => {
    onIngredientSelect(selectedItems.map(item => item.name));
  };

  return (
    <Card className="h-full bg-white dark:bg-zinc-900 border-green-200 dark:border-zinc-800 shadow-lg flex flex-col" suppressHydrationWarning>
      <CardHeader className="bg-gradient-to-r from-emerald-700 to-teal-800 text-white rounded-t-lg py-4 px-5">
        <CardTitle className="flex items-center text-xl font-bold gap-2">
          <ShoppingBasket className="h-5 w-5 text-emerald-300" />
          <span>Eco Grocery List</span>
        </CardTitle>
      </CardHeader>

      <CardContent className="p-4 flex-grow flex flex-col overflow-hidden" suppressHydrationWarning>
        <p className="text-xs text-muted-foreground mb-3">
          Select near-expiry ingredients to generate zero-waste recipes:
        </p>

        <ScrollArea className="flex-grow pr-2 mb-4 h-[350px]">
          <div className="space-y-2.5">
            {groceryItems.map(item => {
              const isSelected = selectedItems.some(i => i.id === item.id);
              return (
                <button
                  key={item.id}
                  type="button"
                  suppressHydrationWarning
                  onClick={() => toggleItemSelection(item)}
                  className={`w-full text-left p-3 rounded-xl border transition-all flex items-center justify-between text-xs ${
                    isSelected 
                      ? 'bg-emerald-50 dark:bg-zinc-800 border-emerald-500 font-semibold shadow-sm' 
                      : 'bg-zinc-50/80 dark:bg-zinc-800/40 border-zinc-200 dark:border-zinc-700 hover:border-emerald-300'
                  }`}
                >
                  <div className="flex items-center gap-2.5">
                    <div className={`w-4 h-4 rounded flex items-center justify-center border ${isSelected ? 'bg-emerald-600 border-emerald-600 text-white' : 'border-zinc-400'}`}>
                      {isSelected && <Check className="w-3 h-3" />}
                    </div>
                    <span className="text-zinc-900 dark:text-zinc-100 font-medium">{item.name}</span>
                  </div>

                  <div className="flex items-center gap-2">
                    <Badge variant="outline" className="text-[10px] border-emerald-300 text-emerald-700 dark:text-emerald-300">
                      {item.category}
                    </Badge>
                    <span className="text-[10px] text-zinc-400 font-mono">Exp: {item.expiryDate.split('-').slice(1).join('/')}</span>
                  </div>
                </button>
              );
            })}
          </div>
        </ScrollArea>

        <Button
          suppressHydrationWarning
          className="w-full bg-emerald-600 hover:bg-emerald-700 text-white font-semibold py-5 rounded-xl text-xs transition"
          onClick={handleSendToChat}
          disabled={selectedItems.length === 0}
        >
          <Leaf className="mr-2 h-4 w-4" />
          Generate Eco Recipes ({selectedItems.length} Selected)
        </Button>
      </CardContent>
    </Card>
  );
}