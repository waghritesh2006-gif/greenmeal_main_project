'use client';

import { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import { 
  Sprout, Leaf, Scale, Droplets, Thermometer, Calendar, 
  CheckCircle, AlertCircle, RefreshCw, Award, Plus, ArrowRight, ShieldCheck,
  BookOpen, FileText, Check, HelpCircle, Info, Sparkles
} from 'lucide-react';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Badge } from '@/components/ui/badge';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter, DialogDescription } from '@/components/ui/dialog';
import { 
  optimizeCnBlend, 
  evaluateCompostPhaseAndTelemetry, 
  estimateFinalYieldAndNpk 
} from '@/lib/services/compostEngine';

export default function CompostModule() {
  // C:N Blend Optimizer State
  const [targetCnRatio, setTargetCnRatio] = useState(30);
  const [greenWeightKg, setGreenWeightKg] = useState(100);
  const [greenMoisture, setGreenMoisture] = useState(75);
  const [greenCarbon, setGreenCarbon] = useState(48);
  const [greenNitrogen, setGreenNitrogen] = useState(3.2);

  const [brownName, setBrownName] = useState('Dry Sawdust');
  const [brownMoisture, setBrownMoisture] = useState(10);
  const [brownCarbon, setBrownCarbon] = useState(50);
  const [brownNitrogen, setBrownNitrogen] = useState(0.5);

  const [optimizationResult, setOptimizationResult] = useState(null);
  const [yieldEstimate, setYieldEstimate] = useState(null);

  // Active Batch Telemetry & Phase State
  const [batchDay, setBatchDay] = useState(7);
  const [batchTempC, setBatchTempC] = useState(63);
  const [batchMoisture, setBatchMoisture] = useState(52);
  const [turningPerformed, setTurningPerformed] = useState(false);
  const [phaseEvaluation, setPhaseEvaluation] = useState(null);

  // Manual Tab
  const [manualTab, setManualTab] = useState('recipe');

  // UI Toast Feedback
  const [toastMessage, setToastMessage] = useState('');

  // Dialog State for New Batch Modal
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [newBatchNumber, setNewBatchNumber] = useState('CMP-2026-003');

  // Active Batches List
  const [batches, setBatches] = useState([
    {
      id: 'batch-001',
      number: 'CMP-2026-001',
      phase: 'THERMOPHILIC',
      startDate: '2026-08-24',
      day: 7,
      cnRatio: 30.0,
      initialWetKg: 138.1,
      estimatedDryYieldKg: 32.6,
      npk: '2.2-0.9-0.9',
      quality: 'Grade A (Premium Organic)'
    },
    {
      id: 'batch-002',
      number: 'CMP-2026-002',
      phase: 'CURING',
      startDate: '2026-07-20',
      day: 42,
      cnRatio: 28.5,
      initialWetKg: 300.0,
      estimatedDryYieldKg: 75.0,
      npk: '2.5-1.1-1.0',
      quality: 'Grade A (Premium Organic)'
    }
  ]);

  // Trigger Toast Notification
  const triggerToast = (msg) => {
    setToastMessage(msg);
    setTimeout(() => setToastMessage(''), 3500);
  };

  // Recalculate C:N optimization whenever recipe inputs change
  useEffect(() => {
    const greenMaterials = [
      {
        name: 'Green Food Waste / Manure',
        materialType: 'GREEN',
        wetWeightKg: Number(greenWeightKg),
        moisturePercent: Number(greenMoisture),
        carbonPercent: Number(greenCarbon),
        nitrogenPercent: Number(greenNitrogen),
      }
    ];

    const availableBrown = {
      name: brownName,
      moisturePercent: Number(brownMoisture),
      carbonPercent: Number(brownCarbon),
      nitrogenPercent: Number(brownNitrogen),
    };

    const opt = optimizeCnBlend({
      targetCnRatio,
      greenMaterials,
      availableBrownMaterial: availableBrown,
    });

    setOptimizationResult(opt);

    // Calculate NPK and dry yield estimation
    const yieldEst = estimateFinalYieldAndNpk(opt.ingredients);
    setYieldEstimate(yieldEst);
  }, [
    targetCnRatio, greenWeightKg, greenMoisture, greenCarbon, greenNitrogen,
    brownName, brownMoisture, brownCarbon, brownNitrogen
  ]);

  // Evaluate Phase Progression & Telemetry Alerts
  useEffect(() => {
    const evalRes = evaluateCompostPhaseAndTelemetry({
      currentPhase: 'THERMOPHILIC',
      dayNumber: batchDay,
      temperatureC: batchTempC,
      moisturePercent: batchMoisture,
      turningPerformed,
    });
    setPhaseEvaluation(evalRes);
  }, [batchDay, batchTempC, batchMoisture, turningPerformed]);

  // Perform Pile Turn Action
  const handlePerformTurn = () => {
    setTurningPerformed(true);
    triggerToast('Scheduled Aeration & Pile Turning Logged Successfully!');
  };

  // Hydrate Action
  const handleAddWater = () => {
    setBatchMoisture(55);
    triggerToast('Water Added. Moisture Level Restored to 55% Optimal Zone.');
  };

  // Initialize New Batch
  const handleCreateBatch = () => {
    if (!optimizationResult || !yieldEstimate) return;

    const newEntry = {
      id: `batch-${Date.now()}`,
      number: newBatchNumber || `CMP-2026-${Math.floor(100 + Math.random() * 900)}`,
      phase: 'MESOPHILIC',
      startDate: new Date().toISOString().split('T')[0],
      day: 1,
      cnRatio: optimizationResult.optimizedBlend.achievedCnRatio,
      initialWetKg: optimizationResult.optimizedBlend.totalWetWeightKg,
      estimatedDryYieldKg: yieldEstimate.estimatedDryYieldKg,
      npk: yieldEstimate.npkRating.npkRatioString,
      quality: yieldEstimate.qualityGrade
    };

    setBatches([newEntry, ...batches]);
    setIsModalOpen(false);
    triggerToast(`Compost Batch ${newEntry.number} Initialized!`);
  };

  return (
    <div className="space-y-6 pb-10">
      {/* Toast Notification Banner */}
      {toastMessage && (
        <motion.div 
          initial={{ opacity: 0, y: -20 }} 
          animate={{ opacity: 1, y: 0 }} 
          className="fixed top-5 right-5 z-50 flex items-center gap-2 bg-emerald-600 text-white px-4 py-3 rounded-xl shadow-2xl font-medium text-sm"
        >
          <Check className="h-5 w-5" /> {toastMessage}
        </motion.div>
      )}

      {/* Header Banner */}
      <div className="relative overflow-hidden rounded-2xl bg-gradient-to-r from-teal-800 via-emerald-700 to-green-900 p-6 text-white shadow-xl">
        <div className="relative z-10 flex flex-col md:flex-row md:items-center justify-between gap-4">
          <div>
            <div className="inline-flex items-center gap-2 rounded-full bg-teal-500/20 px-3 py-1 text-xs font-semibold text-teal-200 backdrop-blur-md mb-2">
              <Sprout className="h-3.5 w-3.5" /> Module 2: Aerobic & Digestate Composting Standard Operating Manual
            </div>
            <h1 className="text-3xl font-extrabold tracking-tight">Organic Fertilizer & Composting Tracker</h1>
            <p className="text-teal-100 text-sm mt-1 max-w-2xl">
              Optimize C:N ratio recipes (target 25:1 to 30:1), monitor thermal phase progression, automate aeration triggers, and calculate N-P-K fertilizer yield.
            </p>
          </div>
          <div className="flex items-center gap-3 bg-white/10 backdrop-blur-md rounded-xl p-3 border border-white/20">
            <Award className="h-8 w-8 text-emerald-300" />
            <div>
              <p className="text-xs text-teal-200">Target C:N Ratio</p>
              <p className="text-lg font-bold">25:1 - 30:1</p>
            </div>
          </div>
        </div>
        <div className="absolute -right-10 -bottom-10 h-48 w-48 rounded-full bg-teal-500/10 blur-3xl" />
      </div>

      {/* Phase Progression Timeline Tracker */}
      <Card className="border-teal-200 bg-white/90 dark:bg-zinc-900/90 shadow-md">
        <CardHeader className="pb-3">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
            <div>
              <CardTitle className="text-lg font-bold text-teal-950 dark:text-teal-100 flex items-center gap-2">
                <Calendar className="h-5 w-5 text-teal-600" /> Active Batch Lifecycle Progression: CMP-2026-001
              </CardTitle>
              <CardDescription>Day {batchDay} of 45-day composting timeline</CardDescription>
            </div>
            <Badge className="bg-emerald-600 text-white font-semibold self-start sm:self-auto text-xs px-3 py-1">
              Phase: {phaseEvaluation?.determinedPhase}
            </Badge>
          </div>
        </CardHeader>
        <CardContent className="space-y-4">
          {/* Phase Stepper Bar */}
          <div className="grid grid-cols-2 md:grid-cols-4 gap-2 text-center text-xs font-semibold">
            <div className={`p-3 rounded-xl border transition ${phaseEvaluation?.determinedPhase === 'MESOPHILIC' ? 'bg-amber-100 border-amber-400 text-amber-900 font-bold shadow' : 'bg-zinc-50 border-zinc-200 text-zinc-500'}`}>
              <p>Mesophilic</p>
              <p className="text-[10px] font-normal text-zinc-500">Days 1–3 (20-40°C)</p>
            </div>
            <div className={`p-3 rounded-xl border transition ${phaseEvaluation?.determinedPhase === 'THERMOPHILIC' ? 'bg-emerald-100 border-emerald-500 text-emerald-950 font-bold shadow' : 'bg-zinc-50 border-zinc-200 text-zinc-500'}`}>
              <p className="flex items-center justify-center gap-1">
                Thermophilic <ShieldCheck className="h-3.5 w-3.5 text-emerald-600" />
              </p>
              <p className="text-[10px] font-normal text-zinc-500">Days 4–21 (40-65°C)</p>
            </div>
            <div className={`p-3 rounded-xl border transition ${phaseEvaluation?.determinedPhase === 'COOLING' ? 'bg-blue-100 border-blue-400 text-blue-900 font-bold shadow' : 'bg-zinc-50 border-zinc-200 text-zinc-500'}`}>
              <p>Cooling Phase</p>
              <p className="text-[10px] font-normal text-zinc-500">Days 21–35 (&lt;40°C)</p>
            </div>
            <div className={`p-3 rounded-xl border transition ${phaseEvaluation?.determinedPhase === 'CURING' ? 'bg-teal-100 border-teal-500 text-teal-950 font-bold shadow' : 'bg-zinc-50 border-zinc-200 text-zinc-500'}`}>
              <p>Curing & Maturation</p>
              <p className="text-[10px] font-normal text-zinc-500">Days 35–60</p>
            </div>
          </div>

          <div className="w-full bg-zinc-100 h-2.5 rounded-full overflow-hidden">
            <div className="bg-emerald-600 h-full rounded-full transition-all duration-500" style={{ width: `${Math.min((batchDay / 45) * 100, 100)}%` }} />
          </div>

          {/* Interactive Simulation Controls */}
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 pt-2 bg-teal-50/50 dark:bg-zinc-800/40 p-4 rounded-xl border border-teal-100">
            <div>
              <div className="flex justify-between text-xs font-semibold text-zinc-700 dark:text-zinc-300 mb-1">
                <span>Compost Temperature:</span>
                <span className="text-emerald-700 font-bold">{batchTempC} °C</span>
              </div>
              <input 
                type="range" min="20" max="75" value={batchTempC} 
                onChange={(e) => setBatchTempC(Number(e.target.value))}
                className="w-full accent-emerald-600 cursor-pointer h-1.5 bg-zinc-200 rounded-lg"
              />
            </div>

            <div>
              <div className="flex justify-between text-xs font-semibold text-zinc-700 dark:text-zinc-300 mb-1">
                <span>Moisture Level:</span>
                <span className="text-teal-700 font-bold">{batchMoisture} %</span>
              </div>
              <input 
                type="range" min="20" max="80" value={batchMoisture} 
                onChange={(e) => setBatchMoisture(Number(e.target.value))}
                className="w-full accent-teal-600 cursor-pointer h-1.5 bg-zinc-200 rounded-lg"
              />
            </div>

            <div>
              <div className="flex justify-between text-xs font-semibold text-zinc-700 dark:text-zinc-300 mb-1">
                <span>Simulate Day:</span>
                <span className="text-zinc-900 font-bold">Day {batchDay}</span>
              </div>
              <input 
                type="range" min="1" max="50" value={batchDay} 
                onChange={(e) => setBatchDay(Number(e.target.value))}
                className="w-full accent-zinc-700 cursor-pointer h-1.5 bg-zinc-200 rounded-lg"
              />
            </div>
          </div>

          {/* Automated Turning & Moisture Action Alerts */}
          {phaseEvaluation && phaseEvaluation.alerts.length > 0 && (
            <div className="space-y-2 pt-1">
              {phaseEvaluation.alerts.map((alert, idx) => (
                <div key={idx} className="flex flex-col sm:flex-row sm:items-center justify-between p-3.5 rounded-xl bg-amber-50 border border-amber-200 text-amber-900 dark:bg-amber-950/40 dark:border-amber-800 dark:text-amber-200 text-xs font-medium gap-2">
                  <div className="flex items-center gap-2">
                    <AlertCircle className="h-4 w-4 text-amber-600 shrink-0" />
                    <span>{alert.message}</span>
                  </div>
                  <div className="flex items-center gap-2 self-end sm:self-auto">
                    {alert.code === 'LOW_MOISTURE_ALERT' && (
                      <Button size="sm" onClick={handleAddWater} className="bg-blue-600 hover:bg-blue-700 text-white text-[11px] h-7 px-3">
                        <Droplets className="mr-1 h-3 w-3" /> Add Water (Hydrate)
                      </Button>
                    )}
                    {phaseEvaluation.actionRequired.includes('TURN_PILE') && !turningPerformed && (
                      <Button size="sm" onClick={handlePerformTurn} className="bg-amber-600 hover:bg-amber-700 text-white text-[11px] h-7 px-3">
                        <RefreshCw className="mr-1 h-3 w-3" /> Mark Turn Performed
                      </Button>
                    )}
                  </div>
                </div>
              ))}
            </div>
          )}
        </CardContent>
      </Card>

      {/* C:N Ratio Blend Optimizer & NPK Estimator Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Ingredient Blend Builder */}
        <Card className="lg:col-span-6 border-teal-200 bg-white/90 dark:bg-zinc-900/90 shadow-md">
          <CardHeader>
            <CardTitle className="text-lg font-bold text-teal-950 dark:text-teal-100 flex items-center gap-2">
              <Scale className="h-5 w-5 text-emerald-600" /> Carbon-to-Nitrogen (C:N) Recipe Builder
            </CardTitle>
            <CardDescription>Input Green Waste metrics to calculate required Brown Waste additions.</CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div>
              <div className="flex justify-between items-center mb-1">
                <Label htmlFor="targetCn">Target C:N Ratio</Label>
                <Badge variant="outline" className="font-mono text-xs text-emerald-700 font-bold">{targetCnRatio}:1</Badge>
              </div>
              <input 
                type="range" min="20" max="40" value={targetCnRatio} 
                onChange={(e) => setTargetCnRatio(Number(e.target.value))}
                className="w-full accent-emerald-600 cursor-pointer h-1.5 bg-zinc-200 rounded-lg"
              />
            </div>

            {/* Green Materials Input Box */}
            <div className="bg-emerald-50/60 dark:bg-zinc-800/60 p-3.5 rounded-xl border border-emerald-100 space-y-3">
              <div className="flex items-center justify-between">
                <span className="text-xs font-bold text-emerald-900 dark:text-emerald-300 flex items-center gap-1">
                  <Leaf className="h-3.5 w-3.5 text-emerald-600" /> Green Waste (Nitrogen-Rich Input)
                </span>
              </div>
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <Label className="text-xs">Wet Mass (kg)</Label>
                  <Input type="number" value={greenWeightKg} onChange={(e) => setGreenWeightKg(Number(e.target.value))} className="mt-1 h-8 text-xs border-emerald-300" />
                </div>
                <div>
                  <Label className="text-xs">Moisture (%)</Label>
                  <Input type="number" value={greenMoisture} onChange={(e) => setGreenMoisture(Number(e.target.value))} className="mt-1 h-8 text-xs border-emerald-300" />
                </div>
              </div>
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <Label className="text-xs">Carbon C (%)</Label>
                  <Input type="number" value={greenCarbon} onChange={(e) => setGreenCarbon(Number(e.target.value))} className="mt-1 h-8 text-xs border-emerald-300" />
                </div>
                <div>
                  <Label className="text-xs">Nitrogen N (%)</Label>
                  <Input type="number" value={greenNitrogen} onChange={(e) => setGreenNitrogen(Number(e.target.value))} className="mt-1 h-8 text-xs border-emerald-300" />
                </div>
              </div>
            </div>

            {/* Brown Materials Input Box */}
            <div className="bg-amber-50/60 dark:bg-zinc-800/60 p-3.5 rounded-xl border border-amber-100 space-y-3">
              <div className="flex items-center justify-between">
                <span className="text-xs font-bold text-amber-900 dark:text-amber-300 flex items-center gap-1">
                  <Sprout className="h-3.5 w-3.5 text-amber-600" /> Brown Waste (Carbon-Rich Material)
                </span>
              </div>
              <div>
                <Label className="text-xs">Material Selection</Label>
                <Select value={brownName} onValueChange={(val) => setBrownName(val)}>
                  <SelectTrigger className="mt-1 h-8 text-xs border-amber-300">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="Dry Sawdust">Dry Sawdust (C:N 400:1)</SelectItem>
                    <SelectItem value="Dry Leaves">Dry Leaves (C:N 60:1)</SelectItem>
                    <SelectItem value="Straw / Stalks">Straw & Crop Residue (C:N 80:1)</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Calculated Recipe Output & NPK Ratings */}
        <Card className="lg:col-span-6 border-teal-200 bg-gradient-to-br from-teal-50/50 to-emerald-50/30 dark:from-zinc-900 dark:to-zinc-950 shadow-md">
          <CardHeader>
            <CardTitle className="text-lg font-bold text-teal-950 dark:text-teal-100 flex items-center gap-2">
              <Award className="h-5 w-5 text-emerald-600" /> Optimized Recipe & NPK Rating Output
            </CardTitle>
            <CardDescription>Automatic brown waste addition and estimated fertilizer quality.</CardDescription>
          </CardHeader>
          <CardContent className="space-y-6">
            {optimizationResult && yieldEstimate && (
              <>
                {/* Required Brown Waste Card */}
                <div className="bg-white dark:bg-zinc-800 p-4 rounded-xl border border-teal-200 shadow-sm flex items-center justify-between">
                  <div>
                    <p className="text-xs text-muted-foreground font-medium">Required Additional Brown Waste</p>
                    <p className="text-2xl font-black text-amber-700 dark:text-amber-400 mt-0.5">
                      + {optimizationResult.requiredBrownMaterial.wetWeightKg} <span className="text-sm font-semibold">kg</span>
                    </p>
                    <p className="text-[11px] text-zinc-500">{optimizationResult.requiredBrownMaterial.name}</p>
                  </div>
                  <div className="text-right">
                    <p className="text-xs text-muted-foreground font-medium">Achieved C:N Blend</p>
                    <p className="text-2xl font-black text-emerald-700 dark:text-emerald-400 mt-0.5">
                      {optimizationResult.optimizedBlend.achievedCnRatio}:1
                    </p>
                  </div>
                </div>

                {/* Estimated Dry Yield & NPK Badges */}
                <div className="grid grid-cols-2 gap-3">
                  <div className="bg-white dark:bg-zinc-800 p-3.5 rounded-xl border border-teal-100">
                    <p className="text-xs text-muted-foreground font-medium">Estimated Dry Compost Yield</p>
                    <p className="text-xl font-bold text-teal-900 dark:text-teal-100 mt-1">
                      {yieldEstimate.estimatedDryYieldKg} kg
                    </p>
                    <p className="text-[10px] text-zinc-500 mt-0.5">~45% dry matter decomposition loss</p>
                  </div>

                  <div className="bg-white dark:bg-zinc-800 p-3.5 rounded-xl border border-teal-100">
                    <p className="text-xs text-muted-foreground font-medium">Quality Grade</p>
                    <Badge className="bg-emerald-600 text-white font-semibold mt-1">
                      {yieldEstimate.qualityGrade}
                    </Badge>
                  </div>
                </div>

                {/* N-P-K Breakdown Cards */}
                <div className="space-y-2">
                  <p className="text-xs font-bold uppercase tracking-wider text-teal-900 dark:text-teal-200">
                    Estimated N-P-K Nutrient Analysis
                  </p>
                  <div className="grid grid-cols-3 gap-2 text-center">
                    <div className="bg-emerald-500/10 border border-emerald-500/20 p-2.5 rounded-xl">
                      <p className="text-[11px] font-bold text-emerald-800 dark:text-emerald-300">Nitrogen (N)</p>
                      <p className="text-lg font-black text-emerald-700 dark:text-emerald-400">{yieldEstimate.npkRating.nPercent}%</p>
                    </div>
                    <div className="bg-teal-500/10 border border-teal-500/20 p-2.5 rounded-xl">
                      <p className="text-[11px] font-bold text-teal-800 dark:text-teal-300">Phosphorus (P₂O₅)</p>
                      <p className="text-lg font-black text-teal-700 dark:text-teal-400">{yieldEstimate.npkRating.pPercent}%</p>
                    </div>
                    <div className="bg-cyan-500/10 border border-cyan-500/20 p-2.5 rounded-xl">
                      <p className="text-[11px] font-bold text-cyan-800 dark:text-cyan-300">Potassium (K₂O)</p>
                      <p className="text-lg font-black text-cyan-700 dark:text-cyan-400">{yieldEstimate.npkRating.kPercent}%</p>
                    </div>
                  </div>
                </div>
              </>
            )}
          </CardContent>
        </Card>
      </div>

      {/* Interactive Aerobic Composting Standard Operating Manual */}
      <Card className="border-teal-200 bg-white/90 dark:bg-zinc-900/90 shadow-md">
        <CardHeader>
          <CardTitle className="text-lg font-bold text-teal-950 dark:text-teal-100 flex items-center gap-2">
            <BookOpen className="h-5 w-5 text-teal-600" /> Aerobic Composting Technical Manual & Quality Standards
          </CardTitle>
          <CardDescription>Operational guidelines for pile maintenance, pathogen destruction, and quality certification.</CardDescription>
        </CardHeader>
        <CardContent>
          <Tabs value={manualTab} onValueChange={setManualTab} className="w-full">
            <TabsList className="grid w-full grid-cols-3 bg-teal-50 dark:bg-zinc-800">
              <TabsTrigger value="recipe" className="text-xs font-semibold">C:N Recipe Manual</TabsTrigger>
              <TabsTrigger value="pfrp" className="text-xs font-semibold">PFRP Pathogen Rules</TabsTrigger>
              <TabsTrigger value="quality" className="text-xs font-semibold">Quality & Heavy Metals</TabsTrigger>
            </TabsList>

            <TabsContent value="recipe" className="mt-4 space-y-3 text-sm text-zinc-700 dark:text-zinc-300">
              <div className="p-4 rounded-xl bg-teal-50/50 dark:bg-zinc-800/50 border border-teal-100 space-y-2">
                <h4 className="font-bold text-teal-900 dark:text-teal-200 flex items-center gap-1.5">
                  <Info className="h-4 w-4 text-teal-600" /> C:N Ratio (25:1 to 30:1) & Moisture Baseline
                </h4>
                <p className="text-xs leading-relaxed">
                  Micro-organisms require Carbon for energy and Nitrogen for protein synthesis. A starting ratio of 25–30 parts Carbon to 1 part Nitrogen optimizes heat generation. Maintain moisture between <strong>40% and 60%</strong> (resembles a damp, wrung-out sponge).
                </p>
              </div>
            </TabsContent>

            <TabsContent value="pfrp" className="mt-4 space-y-3 text-sm">
              <div className="p-4 rounded-xl bg-emerald-50 dark:bg-emerald-950/40 border border-emerald-200 text-emerald-900 dark:text-emerald-200 space-y-1.5">
                <h4 className="font-bold text-sm flex items-center gap-1.5">
                  <ShieldCheck className="h-4 w-4 text-emerald-600" /> EPA Part 503 PFRP Pathogen Elimination
                </h4>
                <p className="text-xs leading-relaxed">
                  Process to Further Reduce Pathogens (PFRP): In windrow composting systems, pile temperatures must remain at or above <strong>55°C (131°F) for at least 15 consecutive days</strong> with a minimum of 5 pile turnings to guarantee destruction of weed seeds and human pathogens (Salmonella, E. coli).
                </p>
              </div>
            </TabsContent>

            <TabsContent value="quality" className="mt-4 space-y-3 text-xs font-mono text-zinc-800 dark:text-zinc-200">
              <div className="p-4 rounded-xl bg-zinc-50 dark:bg-zinc-800/80 border border-zinc-200 dark:border-zinc-700 space-y-2">
                <p className="font-bold text-teal-900 dark:text-teal-300 font-sans text-sm">Grade A Fertilizer Compliance Criteria</p>
                <div className="bg-white dark:bg-zinc-900 p-3 rounded-lg border text-[11px] space-y-1 overflow-x-auto">
                  <p>• Solvita Maturity Index: &gt;= 7 (Finished Compost / Minimal CO2 evolution)</p>
                  <p>• Final C:N Ratio: &lt; 20:1</p>
                  <p>• Heavy Metals Compliance: Arsenic &lt; 41 mg/kg, Cadmium &lt; 39 mg/kg, Lead &lt; 300 mg/kg</p>
                </div>
              </div>
            </TabsContent>
          </Tabs>
        </CardContent>
      </Card>

      {/* Active Compost Batches Inventory Table */}
      <Card className="border-teal-200 bg-white/90 dark:bg-zinc-900/90 shadow-md">
        <CardHeader>
          <CardTitle className="text-lg font-bold text-teal-950 dark:text-teal-100 flex items-center justify-between">
            <span>Compost Batches & Fertilizer Inventory</span>
            <Button onClick={() => setIsModalOpen(true)} size="sm" className="bg-emerald-600 hover:bg-emerald-700 text-white text-xs">
              <Plus className="mr-1 h-3.5 w-3.5" /> Initialize New Batch
            </Button>
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="overflow-x-auto">
            <table className="w-full text-left text-sm">
              <thead className="bg-teal-50 dark:bg-zinc-800 text-xs font-semibold text-teal-950 dark:text-teal-200 uppercase">
                <tr>
                  <th className="p-3">Batch Number</th>
                  <th className="p-3">Phase</th>
                  <th className="p-3">C:N Ratio</th>
                  <th className="p-3">Initial Wet Mass</th>
                  <th className="p-3">Est. Dry Yield</th>
                  <th className="p-3">N-P-K Rating</th>
                  <th className="p-3">Quality Grade</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-zinc-200 dark:divide-zinc-800">
                {batches.map((batch) => (
                  <tr key={batch.id} className="hover:bg-teal-50/50 dark:hover:bg-zinc-800/50 transition">
                    <td className="p-3 font-mono text-xs font-bold text-teal-900 dark:text-teal-200">{batch.number}</td>
                    <td className="p-3">
                      <Badge variant="outline" className="font-semibold text-xs border-teal-300 text-teal-800">
                        {batch.phase} (Day {batch.day})
                      </Badge>
                    </td>
                    <td className="p-3 font-medium">{batch.cnRatio}:1</td>
                    <td className="p-3">{batch.initialWetKg} kg</td>
                    <td className="p-3 font-bold text-emerald-700 dark:text-emerald-400">{batch.estimatedDryYieldKg} kg</td>
                    <td className="p-3 font-mono font-bold text-xs text-teal-700">{batch.npk}</td>
                    <td className="p-3 text-xs">
                      <Badge className="bg-emerald-600">{batch.quality}</Badge>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </CardContent>
      </Card>

      {/* Initialize New Batch Modal */}
      <Dialog open={isModalOpen} onOpenChange={setIsModalOpen}>
        <DialogContent className="sm:max-w-md bg-white dark:bg-zinc-900 border border-teal-200">
          <DialogHeader>
            <DialogTitle className="text-teal-900 dark:text-teal-100 flex items-center gap-2">
              <Plus className="h-5 w-5 text-emerald-600" /> Initialize New Compost Batch
            </DialogTitle>
            <DialogDescription>Create a new batch using current C:N recipe builder baseline.</DialogDescription>
          </DialogHeader>
          <div className="space-y-4 py-2">
            <div>
              <Label>Batch Identifier</Label>
              <Input 
                value={newBatchNumber} 
                onChange={(e) => setNewBatchNumber(e.target.value)} 
                className="mt-1 border-teal-300"
              />
            </div>
            {optimizationResult && (
              <div className="p-3 rounded-lg bg-teal-50 dark:bg-zinc-800 text-xs space-y-1">
                <p className="font-bold text-teal-900 dark:text-teal-200">Recipe Summary:</p>
                <p>• Initial Wet Weight: {optimizationResult.optimizedBlend.totalWetWeightKg} kg</p>
                <p>• Achieved C:N Ratio: {optimizationResult.optimizedBlend.achievedCnRatio}:1</p>
                <p>• Est. Dry Yield: {yieldEstimate?.estimatedDryYieldKg} kg</p>
              </div>
            )}
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setIsModalOpen(false)}>Cancel</Button>
            <Button onClick={handleCreateBatch} className="bg-emerald-600 hover:bg-emerald-700 text-white">Initialize Batch</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}
