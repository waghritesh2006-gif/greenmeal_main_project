import { NextResponse } from 'next/server';
import { CompostOptimizeSchema } from '@/lib/validations/compostSchemas';
import { optimizeCnBlend } from '@/lib/services/compostEngine';

export async function POST(req) {
  try {
    const body = await req.json();
    const validationResult = CompostOptimizeSchema.safeParse(body);

    if (!validationResult.success) {
      return NextResponse.json({
        success: false,
        error: 'Validation Error',
        details: validationResult.error.flatten().fieldErrors,
      }, { status: 400 });
    }

    const { targetCnRatio, greenMaterials, availableBrownMaterial } = validationResult.data;

    // Run C:N blend optimizer
    const optimizationResult = optimizeCnBlend({
      targetCnRatio,
      greenMaterials,
      availableBrownMaterial,
    });

    return NextResponse.json({
      success: true,
      data: optimizationResult,
    });
  } catch (error) {
    return NextResponse.json({
      success: false,
      error: 'Internal Server Error',
      message: error.message,
    }, { status: 500 });
  }
}
