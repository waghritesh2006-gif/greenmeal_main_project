import { NextResponse } from 'next/server';
import { BiogasLogSchema } from '@/lib/validations/biogasSchemas';
import { calculateBiogasYield, evaluateDigesterHealth } from '@/lib/services/biogasEngine';

export async function POST(req) {
  try {
    const body = await req.json();

    // Partial validation for calculator
    const validationResult = BiogasLogSchema.partial().safeParse(body);
    if (!validationResult.success) {
      return NextResponse.json({
        success: false,
        error: 'Validation Error',
        details: validationResult.error.flatten().fieldErrors,
      }, { status: 400 });
    }

    const data = validationResult.data;

    // Calculate Biogas & Energy Yield
    const yieldResult = calculateBiogasYield({
      feedstockCategory: data.feedstockCategory || 'CATTLE_MANURE',
      feedstockWeightKg: data.feedstockWeightKg || 1000,
      tsPercent: data.tsPercent,
      vsPercent: data.vsPercent,
      biogasYieldPerKgVs: data.biogasYieldPerKgVs,
      methaneContentPercent: data.methaneContentPercent,
      digesterCapacityM3: data.digesterCapacityM3 || 100,
    });

    // Evaluate Health Telemetry if provided
    let healthReport = null;
    if (data.temperatureC !== undefined && data.phLevel !== undefined && data.pressureBar !== undefined) {
      healthReport = evaluateDigesterHealth({
        temperatureC: data.temperatureC,
        phLevel: data.phLevel,
        pressureBar: data.pressureBar,
      }, data.currentStorageLevelM3 || 0, 100);
    }

    return NextResponse.json({
      success: true,
      data: {
        ...yieldResult,
        healthReport,
      },
    });
  } catch (error) {
    return NextResponse.json({
      success: false,
      error: 'Internal Server Error',
      message: error.message,
    }, { status: 500 });
  }
}
