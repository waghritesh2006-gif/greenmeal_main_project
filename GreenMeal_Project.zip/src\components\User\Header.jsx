'use client';

import { useState, useEffect, useRef } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { 
  Menu, X, Search, Bell, Sun, Moon, Settings, CheckCircle2, 
  AlertTriangle, Info, Trash2, Check, Sliders, Shield, Volume2, Globe
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';
import { Label } from '@/components/ui/label';
import { Switch } from '@/components/ui/switch';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';

export default function Header({
  isSidebarOpen,
  toggleSidebar,
  selectedComponent,
  searchQuery,
  setSearchQuery,
  searchResults,
  handleSearchSelect,
  isSettingsOpen,
  setIsSettingsOpen
}) {
  // Dark Mode State & Persistence
  const [isDarkMode, setIsDarkMode] = useState(false);

  // Initialize Theme from LocalStorage or System Preference
  useEffect(() => {
    const savedTheme = localStorage.getItem('theme');
    if (savedTheme === 'dark' || (!savedTheme && window.matchMedia('(prefers-color-scheme: dark)').matches)) {
      setIsDarkMode(true);
      document.documentElement.classList.add('dark');
    } else {
      setIsDarkMode(false);
      document.documentElement.classList.remove('dark');
    }
  }, []);

  // Toggle Theme Function
  const toggleTheme = () => {
    const newMode = !isDarkMode;
    setIsDarkMode(newMode);
    if (newMode) {
      document.documentElement.classList.add('dark');
      localStorage.setItem('theme', 'dark');
    } else {
      document.documentElement.classList.remove('dark');
      localStorage.setItem('theme', 'light');
    }
  };

  // Notification State
  const [isNotificationsOpen, setIsNotificationsOpen] = useState(false);
  const notificationRef = useRef(null);
  const settingsRef = useRef(null);

  const [notifications, setNotifications] = useState([
    {
      id: 1,
      title: 'Digester Acidification Warning',
      message: 'Internal pH dropped to 6.2 (ideal 6.8 - 7.5). Methanogen inhibition risk.',
      timestamp: '10 mins ago',
      severity: 'CRITICAL',
      read: false
    },
    {
      id: 2,
      title: 'Scheduled Aeration Due',
      message: 'Compost Batch CMP-2026-001 requires turning for Day 7 aeration.',
      timestamp: '1 hour ago',
      severity: 'HIGH',
      read: false
    },
    {
      id: 3,
      title: 'Gas Storage Near Capacity',
      message: 'Digester storage tank reached 84% capacity (420 / 500 m³).',
      timestamp: '3 hours ago',
      severity: 'LOW',
      read: false
    }
  ]);

  const unreadCount = notifications.filter(n => !n.read).length;

  // Dismiss Notification
  const dismissNotification = (id) => {
    setNotifications(prev => prev.filter(n => n.id !== id));
  };

  // Mark all as read
  const markAllAsRead = () => {
    setNotifications(prev => prev.map(n => ({ ...n, read: true })));
  };

  // Settings Configuration State
  const [settings, setSettings] = useState({
    minPhThreshold: 6.8,
    minTempThreshold: 35.0,
    maxPressureThreshold: 0.05,
    tempUnit: 'C', // 'C' or 'F'
    weightUnit: 'kg', // 'kg' or 'lbs'
    pressureUnit: 'bar', // 'bar' or 'psi'
    emailNotifications: true,
    audioAlarms: true,
    autoRefreshTelemetry: true,
    operatorName: 'GreenMeal Facility Manager'
  });

  // Handle outside clicks to close Notification Panel & Settings Modal
  useEffect(() => {
    const handleClickOutside = (event) => {
      if (notificationRef.current && !notificationRef.current.contains(event.target)) {
        setIsNotificationsOpen(false);
      }
      if (settingsRef.current && !settingsRef.current.contains(event.target)) {
        setIsSettingsOpen(false);
      }
    };

    // Handle Escape Key to close modals
    const handleKeyDown = (event) => {
      if (event.key === 'Escape') {
        setIsNotificationsOpen(false);
        setIsSettingsOpen(false);
      }
    };

    document.addEventListener('mousedown', handleClickOutside);
    document.addEventListener('keydown', handleKeyDown);

    return () => {
      document.removeEventListener('mousedown', handleClickOutside);
      document.removeEventListener('keydown', handleKeyDown);
    };
  }, [setIsSettingsOpen]);

  return (
    <header className="relative z-30 flex items-center justify-between px-6 py-3.5 bg-white/90 dark:bg-zinc-900/90 border-b border-green-200/80 dark:border-zinc-800 shadow-sm backdrop-blur transition-colors">
      {/* Left: Sidebar Toggle & Page Title */}
      <div className="flex items-center gap-3">
        <Button 
          variant="ghost" 
          size="icon" 
          onClick={toggleSidebar} 
          className="text-green-800 dark:text-green-300 hover:bg-green-100 dark:hover:bg-zinc-800"
          aria-label="Toggle Navigation Menu"
        >
          {isSidebarOpen ? <X className="h-5 w-5" /> : <Menu className="h-5 w-5" />}
        </Button>
        <div>
          <h1 className="text-xl font-bold text-green-900 dark:text-green-100 tracking-tight">
            {selectedComponent === 'BiogasModule' ? 'Biogas Plant Management' :
             selectedComponent === 'CompostModule' ? 'Compost Lifecycle Tracker' :
             selectedComponent}
          </h1>
        </div>
      </div>

      {/* Right: Search, Notifications, Settings & Dark Mode Toggle */}
      <div className="flex items-center space-x-3">
        {/* Search Bar */}
        <div className="relative hidden md:block">
          <Input
            type="text"
            placeholder="Search dashboard, analytics..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="w-64 bg-green-50/60 dark:bg-zinc-800/60 border-green-300 dark:border-zinc-700 text-xs focus:ring-green-500 rounded-full pl-9 pr-4"
          />
          <Search className="absolute left-3 top-2.5 h-4 w-4 text-green-600 dark:text-green-400 pointer-events-none" />
          
          {/* Search Results Dropdown */}
          {searchResults.length > 0 && (
            <motion.div
              initial={{ opacity: 0, y: -5 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -5 }}
              className="absolute right-0 z-50 w-full mt-2 bg-white dark:bg-zinc-900 border border-green-200 dark:border-zinc-800 rounded-xl shadow-xl overflow-hidden"
            >
              {searchResults.map((result, index) => (
                <button
                  key={index}
                  className="w-full text-left px-4 py-2.5 text-xs text-green-900 dark:text-green-200 hover:bg-green-50 dark:hover:bg-zinc-800 transition flex items-center justify-between"
                  onClick={() => handleSearchSelect(result.component)}
                >
                  <span>{result.title}</span>
                  <Badge variant="outline" className="text-[10px]">Jump to</Badge>
                </button>
              ))}
            </motion.div>
          )}
        </div>

        {/* Notifications Icon & Dropdown Drawer */}
        <div className="relative" ref={notificationRef}>
          <Button 
            variant="ghost" 
            size="icon" 
            onClick={() => setIsNotificationsOpen(!isNotificationsOpen)} 
            className="relative text-green-800 dark:text-green-300 hover:bg-green-100 dark:hover:bg-zinc-800 rounded-full"
            aria-label="View Notifications"
          >
            <Bell className="h-5 w-5" />
            {unreadCount > 0 && (
              <Badge className="absolute -top-1 -right-1 h-5 w-5 p-0 flex items-center justify-center bg-red-500 text-white text-[10px] font-bold rounded-full animate-pulse">
                {unreadCount}
              </Badge>
            )}
          </Button>

          {/* Interactive Notifications Panel */}
          <AnimatePresence>
            {isNotificationsOpen && (
              <motion.div
                initial={{ opacity: 0, y: 10, scale: 0.95 }}
                animate={{ opacity: 1, y: 0, scale: 1 }}
                exit={{ opacity: 0, y: 10, scale: 0.95 }}
                transition={{ duration: 0.2 }}
                className="absolute right-0 mt-3 w-80 sm:w-96 bg-white dark:bg-zinc-900 border border-green-200 dark:border-zinc-800 rounded-2xl shadow-2xl overflow-hidden z-50"
              >
                {/* Header */}
                <div className="flex items-center justify-between px-4 py-3 bg-green-50/80 dark:bg-zinc-800/80 border-b border-green-100 dark:border-zinc-700">
                  <div className="flex items-center gap-2">
                    <Bell className="h-4 w-4 text-emerald-600 dark:text-emerald-400" />
                    <span className="text-sm font-bold text-green-950 dark:text-green-100">System Notifications</span>
                    <Badge variant="outline" className="text-[10px] bg-white dark:bg-zinc-900 font-mono">{unreadCount} New</Badge>
                  </div>
                  <div className="flex items-center gap-1">
                    {unreadCount > 0 && (
                      <button 
                        onClick={markAllAsRead}
                        className="text-[11px] text-emerald-700 dark:text-emerald-400 hover:underline font-medium mr-2"
                      >
                        Mark all read
                      </button>
                    )}
                    <button 
                      onClick={() => setIsNotificationsOpen(false)}
                      className="text-zinc-500 hover:text-zinc-800 dark:hover:text-zinc-200"
                    >
                      <X className="h-4 w-4" />
                    </button>
                  </div>
                </div>

                {/* Notifications List */}
                <div className="max-h-80 overflow-y-auto divide-y divide-zinc-100 dark:divide-zinc-800">
                  {notifications.length === 0 ? (
                    <div className="p-6 text-center text-xs text-zinc-500">
                      <CheckCircle2 className="h-8 w-8 text-emerald-500 mx-auto mb-2 opacity-50" />
                      All notifications caught up! No active alerts.
                    </div>
                  ) : (
                    notifications.map((item) => (
                      <div 
                        key={item.id} 
                        className={`p-3.5 transition flex items-start justify-between gap-3 ${
                          !item.read ? 'bg-emerald-50/40 dark:bg-zinc-800/40' : 'hover:bg-zinc-50 dark:hover:bg-zinc-800/20'
                        }`}
                      >
                        <div className="flex-1">
                          <div className="flex items-center gap-2">
                            <Badge 
                              className={`text-[9px] px-1.5 py-0 font-mono font-bold uppercase ${
                                item.severity === 'CRITICAL' ? 'bg-red-500 text-white' :
                                item.severity === 'HIGH' ? 'bg-amber-500 text-white' : 'bg-blue-500 text-white'
                              }`}
                            >
                              {item.severity}
                            </Badge>
                            <span className="text-xs font-bold text-zinc-900 dark:text-zinc-100">{item.title}</span>
                          </div>
                          <p className="text-[11px] text-zinc-600 dark:text-zinc-400 mt-1 leading-snug">{item.message}</p>
                          <span className="text-[10px] text-zinc-400 mt-1.5 block font-mono">{item.timestamp}</span>
                        </div>
                        <button 
                          onClick={() => dismissNotification(item.id)}
                          className="text-zinc-400 hover:text-red-500 transition p-1"
                          title="Dismiss notification"
                        >
                          <X className="h-3.5 w-3.5" />
                        </button>
                      </div>
                    ))
                  )}
                </div>
              </motion.div>
            )}
          </AnimatePresence>
        </div>

        {/* Settings Icon Button */}
        <Button 
          variant="ghost" 
          size="icon" 
          onClick={() => setIsSettingsOpen(true)} 
          className="text-green-800 dark:text-green-300 hover:bg-green-100 dark:hover:bg-zinc-800 rounded-full"
          aria-label="Open System Settings"
        >
          <Settings className="h-5 w-5" />
        </Button>

        {/* Dark Mode Toggle Button */}
        <Button 
          variant="ghost" 
          size="icon" 
          onClick={toggleTheme} 
          className="text-green-800 dark:text-green-300 hover:bg-green-100 dark:hover:bg-zinc-800 rounded-full"
          aria-label="Toggle Theme"
        >
          {isDarkMode ? <Sun className="h-5 w-5 text-amber-400" /> : <Moon className="h-5 w-5 text-emerald-700" />}
        </Button>
      </div>

      {/* Settings Modal / Slide-over Drawer */}
      <AnimatePresence>
        {isSettingsOpen && (
          <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/50 backdrop-blur-sm">
            <motion.div
              ref={settingsRef}
              initial={{ opacity: 0, scale: 0.95, y: 10 }}
              animate={{ opacity: 1, scale: 1, y: 0 }}
              exit={{ opacity: 0, scale: 0.95, y: 10 }}
              className="w-full max-w-lg bg-white dark:bg-zinc-900 border border-green-200 dark:border-zinc-800 rounded-2xl shadow-2xl overflow-hidden"
            >
              {/* Settings Header */}
              <div className="flex items-center justify-between p-4 bg-green-50 dark:bg-zinc-800 border-b border-green-100 dark:border-zinc-700">
                <div className="flex items-center gap-2">
                  <Settings className="h-5 w-5 text-emerald-600 dark:text-emerald-400" />
                  <h3 className="text-base font-bold text-green-950 dark:text-green-100">AntiGravity System Settings</h3>
                </div>
                <button 
                  onClick={() => setIsSettingsOpen(false)}
                  className="text-zinc-500 hover:text-zinc-800 dark:hover:text-zinc-200"
                >
                  <X className="h-5 w-5" />
                </button>
              </div>

              {/* Settings Tabs & Options */}
              <div className="p-5 space-y-4">
                <Tabs defaultValue="thresholds" className="w-full">
                  <TabsList className="grid w-full grid-cols-3 bg-green-50 dark:bg-zinc-800">
                    <TabsTrigger value="thresholds" className="text-xs font-semibold">Alert Thresholds</TabsTrigger>
                    <TabsTrigger value="units" className="text-xs font-semibold">Units & Preferences</TabsTrigger>
                    <TabsTrigger value="notifications" className="text-xs font-semibold">System Alarms</TabsTrigger>
                  </TabsList>

                  {/* Thresholds Settings */}
                  <TabsContent value="thresholds" className="mt-4 space-y-4 text-xs">
                    <div>
                      <div className="flex justify-between font-semibold text-zinc-800 dark:text-zinc-200 mb-1">
                        <span>Min Ideal pH Threshold:</span>
                        <span className="font-mono text-emerald-600 font-bold">{settings.minPhThreshold} pH</span>
                      </div>
                      <input 
                        type="range" min="6.0" max="7.2" step="0.1" 
                        value={settings.minPhThreshold} 
                        onChange={(e) => setSettings({ ...settings, minPhThreshold: Number(e.target.value) })}
                        className="w-full accent-emerald-600 cursor-pointer h-1.5 bg-zinc-200 rounded-lg"
                      />
                    </div>

                    <div>
                      <div className="flex justify-between font-semibold text-zinc-800 dark:text-zinc-200 mb-1">
                        <span>Min Ideal Temperature:</span>
                        <span className="font-mono text-amber-600 font-bold">{settings.minTempThreshold} °C</span>
                      </div>
                      <input 
                        type="range" min="30.0" max="40.0" step="0.5" 
                        value={settings.minTempThreshold} 
                        onChange={(e) => setSettings({ ...settings, minTempThreshold: Number(e.target.value) })}
                        className="w-full accent-amber-600 cursor-pointer h-1.5 bg-zinc-200 rounded-lg"
                      />
                    </div>

                    <div>
                      <div className="flex justify-between font-semibold text-zinc-800 dark:text-zinc-200 mb-1">
                        <span>Max Pressure Alarm Threshold:</span>
                        <span className="font-mono text-blue-600 font-bold">{settings.maxPressureThreshold} bar</span>
                      </div>
                      <input 
                        type="range" min="0.03" max="0.10" step="0.005" 
                        value={settings.maxPressureThreshold} 
                        onChange={(e) => setSettings({ ...settings, maxPressureThreshold: Number(e.target.value) })}
                        className="w-full accent-blue-600 cursor-pointer h-1.5 bg-zinc-200 rounded-lg"
                      />
                    </div>
                  </TabsContent>

                  {/* Units Settings */}
                  <TabsContent value="units" className="mt-4 space-y-4 text-xs">
                    <div className="flex items-center justify-between">
                      <span className="font-medium text-zinc-800 dark:text-zinc-200">Temperature Unit</span>
                      <div className="flex gap-2">
                        <Button 
                          size="sm" 
                          variant={settings.tempUnit === 'C' ? 'default' : 'outline'} 
                          onClick={() => setSettings({ ...settings, tempUnit: 'C' })}
                          className="h-7 text-xs px-3"
                        >
                          Celsius (°C)
                        </Button>
                        <Button 
                          size="sm" 
                          variant={settings.tempUnit === 'F' ? 'default' : 'outline'} 
                          onClick={() => setSettings({ ...settings, tempUnit: 'F' })}
                          className="h-7 text-xs px-3"
                        >
                          Fahrenheit (°F)
                        </Button>
                      </div>
                    </div>

                    <div className="flex items-center justify-between">
                      <span className="font-medium text-zinc-800 dark:text-zinc-200">Weight Metric Unit</span>
                      <div className="flex gap-2">
                        <Button 
                          size="sm" 
                          variant={settings.weightUnit === 'kg' ? 'default' : 'outline'} 
                          onClick={() => setSettings({ ...settings, weightUnit: 'kg' })}
                          className="h-7 text-xs px-3"
                        >
                          Kilograms (kg)
                        </Button>
                        <Button 
                          size="sm" 
                          variant={settings.weightUnit === 'lbs' ? 'default' : 'outline'} 
                          onClick={() => setSettings({ ...settings, weightUnit: 'lbs' })}
                          className="h-7 text-xs px-3"
                        >
                          Pounds (lbs)
                        </Button>
                      </div>
                    </div>
                  </TabsContent>

                  {/* Notifications Settings */}
                  <TabsContent value="notifications" className="mt-4 space-y-4 text-xs">
                    <div className="flex items-center justify-between">
                      <span className="font-medium text-zinc-800 dark:text-zinc-200">Email Emergency Alerts</span>
                      <Switch 
                        checked={settings.emailNotifications} 
                        onCheckedChange={(val) => setSettings({ ...settings, emailNotifications: val })}
                      />
                    </div>

                    <div className="flex items-center justify-between">
                      <span className="font-medium text-zinc-800 dark:text-zinc-200">Critical Alarm Sound</span>
                      <Switch 
                        checked={settings.audioAlarms} 
                        onCheckedChange={(val) => setSettings({ ...settings, audioAlarms: val })}
                      />
                    </div>
                  </TabsContent>
                </Tabs>

                <div className="pt-2 flex justify-end gap-2 border-t border-zinc-100 dark:border-zinc-800">
                  <Button variant="outline" onClick={() => setIsSettingsOpen(false)} className="text-xs">
                    Cancel
                  </Button>
                  <Button onClick={() => setIsSettingsOpen(false)} className="bg-emerald-600 hover:bg-emerald-700 text-white text-xs">
                    Save Configurations
                  </Button>
                </div>
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>
    </header>
  );
}
