import { Toaster } from "sonner";
import "./globals.css";

export const metadata = {
  title: "GreenMeal - Sustainability & Food Management",
  description: "Eco-Friendly Food & Sustainability Management Platform",
};

export default function RootLayout({ children }) {
  return (
    <html lang="en" suppressHydrationWarning>
      <body className="antialiased bg-background text-foreground" suppressHydrationWarning>
        {children}
        <Toaster richColors position="top-right" />
      </body>
    </html>
  );
}
