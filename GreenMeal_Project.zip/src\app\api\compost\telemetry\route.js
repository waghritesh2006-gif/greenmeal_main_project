import { NextResponse } from 'next/server';
import { CompostTelemetrySchema } from '@/lib/validations/compostSchemas';
import { evaluateCompostPhaseAndTelemetry } from '@/lib/services/compostEngine';

let telemetryStore = [];

export async function GET(req) {
  const { searchParams } = new URL(req.url);
  const batchId = searchParams.get('batchId');

  let logs = telemetryStore;
  if (batchId) {
    logs = logs.filter(l => l.batchId === batchId);
  }

  return NextResponse.json({
    success: true,
    count: logs.length,
    data: logs,
  });
}

export async function POST(req) {
  try {
    const body = await req.json();
    const validationResult = CompostTelemetrySchema.safeParse(body);

    if (!validationResult.success) {
      return NextResponse.json({
        success: false,
        error: 'Validation Error',
        details: validationResult.error.flatten().fieldErrors,
      }, { status: 400 });
    }

    const { batchId, temperatureC, moisturePercent, ambientTempC, turningPerformed, waterAddedLiters, notes } = validationResult.data;

    // Calculate days elapsed (mock default day 7 for single log evaluation)
    const dayNumber = body.dayNumber || 7;
    const currentPhase = body.currentPhase || 'THERMOPHILIC';

    // Evaluate Phase progression, Moisture reminders, and Turning schedule triggers
    const evaluation = evaluateCompostPhaseAndTelemetry({
      currentPhase,
      dayNumber,
      temperatureC,
      moisturePercent,
      turningPerformed,
    });

    const newTelemetryLog = {
      id: `telemetry-${Date.now()}`,
      batchId,
      dayNumber,
      telemetry: {
        temperatureC,
        moisturePercent,
        ambientTempC,
      },
      actions: {
        turningPerformed,
        waterAddedLiters,
        notes,
      },
      evaluation: {
        determinedPhase: evaluation.determinedPhase,
        alerts: evaluation.alerts,
        actionRequired: evaluation.actionRequired,
        isMoistureOptimal: evaluation.isMoistureOptimal,
        isTemperatureOptimal: evaluation.isTemperatureOptimal,
      },
      loggedAt: new Date().toISOString(),
    };

    telemetryStore.push(newTelemetryLog);

    return NextResponse.json({
      success: true,
      message: 'Telemetry logged and phase/turning schedule evaluated',
      data: newTelemetryLog,
    }, { status: 201 });
  } catch (error) {
    return NextResponse.json({
      success: false,
      error: 'Internal Server Error',
      message: error.message,
    }, { status: 500 });
  }
}
