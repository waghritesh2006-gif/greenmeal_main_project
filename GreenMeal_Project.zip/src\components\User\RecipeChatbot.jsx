'use client';

import React, { useState, useEffect, useRef } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { 
  Send, Bot, User, AlertCircle, ChevronDown, ChevronUp, Leaf, 
  Volume2, StopCircle, Sparkles, Utensils, Clock, Flame, CheckCircle2, RefreshCw
} from 'lucide-react';
import ReactMarkdown from 'react-markdown';
import { GoogleGenerativeAI } from "@google/generative-ai";
import { toast, Toaster } from 'sonner';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Accordion, AccordionContent, AccordionItem, AccordionTrigger } from '@/components/ui/accordion';

const API_KEY = process.env.NEXT_PUBLIC_GEMINI_API_KEY || 'AIzaSyBCuvpypc1y7oCKQZPfctEGtHx5r8edCfo';
const genAI = new GoogleGenerativeAI(API_KEY);

// Curated high-res food image library for reliable image preview (replacing deprecated Unsplash Source)
const FOOD_IMAGE_PREVIEWS = {
  salad: 'https://images.unsplash.com/photo-1512621776951-a57141f2eefd?auto=format&fit=crop&w=600&q=80',
  soup: 'https://images.unsplash.com/photo-1547592180-85f173990554?auto=format&fit=crop&w=600&q=80',
  stew: 'https://images.unsplash.com/photo-1547592180-85f173990554?auto=format&fit=crop&w=600&q=80',
  pasta: 'https://images.unsplash.com/photo-1621996346565-e3d5d6281286?auto=format&fit=crop&w=600&q=80',
  rice: 'https://images.unsplash.com/photo-1512058564366-18510be2db19?auto=format&fit=crop&w=600&q=80',
  omelette: 'https://images.unsplash.com/photo-1525351484163-7529414344d8?auto=format&fit=crop&w=600&q=80',
  chicken: 'https://images.unsplash.com/photo-1598515214211-89d3c73ae83b?auto=format&fit=crop&w=600&q=80',
  smoothie: 'https://images.unsplash.com/photo-1553530666-ba11a7da3888?auto=format&fit=crop&w=600&q=80',
  default: 'https://images.unsplash.com/photo-1498837167922-ddd27525d352?auto=format&fit=crop&w=600&q=80',
};

// Built-in Smart Eco-Recipe Generator (Fallback when API key or network is offline)
function generateFallbackEcoRecipe(query, ingredients = []) {
  const queryLower = (query + ' ' + ingredients.join(' ')).toLowerCase();
  
  let dishTitle = "Zero-Waste Sustainable Medley";
  let prepTime = "20 Mins";
  let carbonOffset = "1.2 kg CO₂e saved";
  let imageUrl = FOOD_IMAGE_PREVIEWS.default;
  let steps = [];

  if (queryLower.includes('tomato') || queryLower.includes('rice') || queryLower.includes('chicken')) {
    dishTitle = "Savory Tomato Herb Rice Bowl";
    prepTime = "25 Mins";
    imageUrl = FOOD_IMAGE_PREVIEWS.rice;
    steps = [
      "Dice tomatoes and saute with olive oil and garlic for 5 minutes until soft.",
      "Add remaining vegetables or shredded chicken to the pan.",
      "Fold in pre-cooked rice and season with black pepper, oregano, and salt.",
      "Garnish with fresh green herbs and serve hot."
    ];
  } else if (queryLower.includes('egg') || queryLower.includes('bread') || queryLower.includes('breakfast')) {
    dishTitle = "Garden Veggie Toast & Skillet Eggs";
    prepTime = "15 Mins";
    imageUrl = FOOD_IMAGE_PREVIEWS.omelette;
    steps = [
      "Toast bread slices until golden brown.",
      "Saute diced tomatoes and greens in a pan for 3 minutes.",
      "Crack eggs into the pan, season with sea salt, and cook to desired doneness.",
      "Serve warm over toasted bread."
    ];
  } else if (queryLower.includes('fruit') || queryLower.includes('apple') || queryLower.includes('smoothie')) {
    dishTitle = "Eco-Boost Green Fruit Smoothie";
    prepTime = "10 Mins";
    imageUrl = FOOD_IMAGE_PREVIEWS.smoothie;
    steps = [
      "Chop fresh fruits and leafy greens.",
      "Add to blender with chilled water or plant-based milk.",
      "Blend on high speed for 60 seconds until creamy.",
      "Pour into glass and enjoy immediately."
    ];
  } else {
    dishTitle = "Eco-Friendly Leftover Veggie Stir-Fry";
    prepTime = "20 Mins";
    imageUrl = FOOD_IMAGE_PREVIEWS.salad;
    steps = [
      "Wash and chop all available surplus vegetables into uniform bite-sized pieces.",
      "Heat sesame oil in a wok or pan over medium-high heat.",
      "Add hard vegetables (carrots, broccoli) first, sauteing for 4 minutes.",
      "Add leafy greens and tomatoes, tossing with soy sauce and ginger for 3 minutes."
    ];
  }

  const recipeMarkdown = `### 🌿 Eco-Friendly Recipe: **${dishTitle}**

* **Preparation Time:** ${prepTime}
* **Environmental Impact:** 🌱 ${carbonOffset}
* **Ingredients Used:** ${ingredients.length > 0 ? ingredients.join(', ') : 'Selected fresh kitchen ingredients'}

#### Instructions:
${steps.map((s, i) => `${i + 1}. ${s}`).join('\n')}

> **Eco Tip:** Utilizing near-expiry kitchen ingredients eliminates methane emissions from landfills and reduces your household carbon footprint!`;

  return {
    content: recipeMarkdown,
    recipeSteps: steps,
    recipeImage: imageUrl
  };
}

export default function RecipeChatbot({ selectedIngredients = [] }) {
  const [mounted, setMounted] = useState(false);
  const [messages, setMessages] = useState([
    { 
      id: 'initial', 
      role: 'assistant', 
      content: "Hello! I'm your **GreenMeal Eco-Friendly Recipe Assistant**. Select ingredients from your grocery list or type any recipe query to reduce food waste!" 
    }
  ]);
  const [input, setInput] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [chatSession, setChatSession] = useState(null);
  const [expandedMessages, setExpandedMessages] = useState({});
  const messagesEndRef = useRef(null);
  const [isSpeaking, setIsSpeaking] = useState(false);
  const speechSynthesisRef = useRef(null);

  useEffect(() => {
    setMounted(true);
  }, []);

  // Initialize Gemini AI Chat Session
  useEffect(() => {
    const initChat = async () => {
      try {
        const model = genAI.getGenerativeModel({ model: "gemini-1.5-flash" });
        const chat = model.startChat({
          generationConfig: {
            temperature: 0.7,
            topP: 0.8,
            maxOutputTokens: 2048,
          },
          history: [],
        });
        setChatSession(chat);
      } catch (err) {
        console.warn('Gemini AI fallback mode active:', err.message);
      }
    };
    initChat();
  }, []);

  // Trigger recipe generation when selectedIngredients prop changes from GroceryList
  useEffect(() => {
    if (selectedIngredients.length > 0) {
      const prompt = `Suggest a quick, eco-friendly recipe using: ${selectedIngredients.join(', ')}. Please provide step-by-step instructions.`;
      handleSubmit(null, prompt);
    }
  }, [selectedIngredients]);

  // Auto-scroll to bottom of chat
  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages]);

  if (!mounted) {
    return (
      <Card className="h-full bg-white dark:bg-zinc-900 border-green-200 dark:border-zinc-800 shadow-lg flex items-center justify-center p-6 text-emerald-800 dark:text-emerald-200">
        <div className="flex items-center gap-2 font-semibold text-xs">
          <RefreshCw className="w-4 h-4 animate-spin text-emerald-600" />
          Initializing Eco-Friendly Recipe Assistant...
        </div>
      </Card>
    );
  }

  // Handle Form Submit
  const handleSubmit = async (e, overrideInput = null) => {
    e?.preventDefault();
    const messageContent = overrideInput || input;
    if (!messageContent.trim()) return;

    const userMsg = { id: Date.now().toString(), role: 'user', content: messageContent };
    setMessages(prev => [...prev, userMsg]);
    setInput('');
    setIsLoading(true);

    try {
      let responseText = '';
      let steps = [];
      let image = null;

      // Attempt Gemini API generation
      if (chatSession) {
        try {
          const result = await chatSession.sendMessage(messageContent);
          responseText = result.response.text();
          
          const stepsMatch = responseText.match(/Steps:([\s\S]*?)(?:\n\n|$)/i);
          steps = stepsMatch ? stepsMatch[1].split('\n').map(s => s.trim()).filter(Boolean) : [];
        } catch (apiErr) {
          console.warn('Gemini API request failed, switching to Smart Fallback:', apiErr);
          const fallback = generateFallbackEcoRecipe(messageContent, selectedIngredients);
          responseText = fallback.content;
          steps = fallback.recipeSteps;
          image = fallback.recipeImage;
        }
      } else {
        // Fallback Engine
        const fallback = generateFallbackEcoRecipe(messageContent, selectedIngredients);
        responseText = fallback.content;
        steps = fallback.recipeSteps;
        image = fallback.recipeImage;
      }

      // Pick food image based on keywords if not set
      if (!image) {
        const lower = messageContent.toLowerCase();
        if (lower.includes('salad')) image = FOOD_IMAGE_PREVIEWS.salad;
        else if (lower.includes('soup') || lower.includes('stew')) image = FOOD_IMAGE_PREVIEWS.soup;
        else if (lower.includes('pasta')) image = FOOD_IMAGE_PREVIEWS.pasta;
        else if (lower.includes('rice')) image = FOOD_IMAGE_PREVIEWS.rice;
        else if (lower.includes('egg') || lower.includes('omelette')) image = FOOD_IMAGE_PREVIEWS.omelette;
        else image = FOOD_IMAGE_PREVIEWS.default;
      }

      const assistantMsg = {
        id: (Date.now() + 1).toString(),
        role: 'assistant',
        content: responseText,
        recipeSteps: steps,
        recipeImage: image
      };

      setMessages(prev => [...prev, assistantMsg]);
    } catch (err) {
      console.error('Chat error:', err);
      toast.error('Could not generate recipe. Please try again.');
    } finally {
      setIsLoading(false);
    }
  };

  const toggleMessageExpansion = (id) => {
    setExpandedMessages(prev => ({ ...prev, [id]: !prev[id] }));
  };

  // Text-to-Speech Voice Notes
  const speakMessage = (text) => {
    if ('speechSynthesis' in window) {
      window.speechSynthesis.cancel();
      // Strip markdown syntax for natural speech
      const cleanText = text.replace(/[*#>`]/g, '');
      const utterance = new SpeechSynthesisUtterance(cleanText);
      utterance.onstart = () => setIsSpeaking(true);
      utterance.onend = () => setIsSpeaking(false);
      utterance.onerror = () => setIsSpeaking(false);

      speechSynthesisRef.current = utterance;
      window.speechSynthesis.speak(utterance);
    } else {
      toast.error('Text-to-speech is not supported in this browser.');
    }
  };

  const stopSpeaking = () => {
    if ('speechSynthesis' in window) {
      window.speechSynthesis.cancel();
      setIsSpeaking(false);
    }
  };

  // Quick Prompt Chips
  const handleChipClick = (chipPrompt) => {
    handleSubmit(null, chipPrompt);
  };

  const renderMessage = (message) => {
    if (message.role === 'user') {
      return <p className="text-sm font-medium">{message.content}</p>;
    }

    const isExpanded = expandedMessages[message.id];
    const rawContent = message.content || '';
    const displayContent = isExpanded || rawContent.length < 250 ? rawContent : rawContent.slice(0, 250) + '...';

    return (
      <div className="space-y-3 text-sm leading-relaxed">
        <div className="prose dark:prose-invert text-emerald-950 dark:text-emerald-100 max-w-none">
          <ReactMarkdown>{displayContent}</ReactMarkdown>
        </div>

        {rawContent.length > 250 && (
          <Button
            variant="ghost"
            size="sm"
            onClick={() => toggleMessageExpansion(message.id)}
            className="text-xs text-emerald-700 dark:text-emerald-300 hover:text-emerald-900 p-0 h-6"
          >
            {isExpanded ? (
              <>
                <ChevronUp className="w-3.5 h-3.5 mr-1" />
                Show Less
              </>
            ) : (
              <>
                <ChevronDown className="w-3.5 h-3.5 mr-1" />
                Read Full Recipe
              </>
            )}
          </Button>
        )}

        {/* Recipe Steps Accordion */}
        {message.recipeSteps && message.recipeSteps.length > 0 && (
          <Accordion type="single" collapsible className="mt-2 bg-white dark:bg-zinc-800 rounded-xl px-3 border border-emerald-200 dark:border-zinc-700">
            <AccordionItem value="steps" className="border-b-0">
              <AccordionTrigger className="text-xs font-bold text-emerald-800 dark:text-emerald-300 py-2">
                <Utensils className="w-3.5 h-3.5 mr-1.5 text-emerald-600" /> View Step-by-Step Cooking Guide
              </AccordionTrigger>
              <AccordionContent className="text-xs space-y-1.5 pb-3">
                <ol className="list-decimal list-inside space-y-1">
                  {message.recipeSteps.map((step, idx) => (
                    <li key={idx} className="text-zinc-700 dark:text-zinc-300">{step}</li>
                  ))}
                </ol>
              </AccordionContent>
            </AccordionItem>
          </Accordion>
        )}

        {/* Recipe Dish Image Preview */}
        {message.recipeImage && (
          <div className="mt-3 overflow-hidden rounded-xl border border-emerald-200 dark:border-zinc-700 shadow-sm max-w-md">
            <img src={message.recipeImage} alt="Eco Recipe Dish" className="w-full h-44 object-cover hover:scale-105 transition duration-300" />
          </div>
        )}

        {/* Voice Note Controls */}
        <div className="flex items-center gap-2 pt-1">
          <Button
            variant="outline"
            size="sm"
            onClick={() => speakMessage(rawContent)}
            className="text-[11px] h-7 border-emerald-300 dark:border-zinc-700 text-emerald-800 dark:text-emerald-200"
          >
            <Volume2 className="w-3.5 h-3.5 mr-1 text-emerald-600" />
            {isSpeaking ? 'Speaking...' : 'Listen Voice Note'}
          </Button>
          {isSpeaking && (
            <Button
              variant="outline"
              size="sm"
              onClick={stopSpeaking}
              className="text-[11px] h-7 border-red-300 text-red-600 hover:bg-red-50"
            >
              <StopCircle className="w-3.5 h-3.5 mr-1" />
              Stop
            </Button>
          )}
        </div>
      </div>
    );
  };

  return (
    <Card className="h-full bg-white dark:bg-zinc-900 border-green-200 dark:border-zinc-800 shadow-lg flex flex-col">
      <Toaster position="top-right" />
      <CardHeader className="bg-gradient-to-r from-emerald-700 to-teal-800 text-white rounded-t-lg py-4 px-5">
        <CardTitle className="flex items-center justify-between text-xl font-bold">
          <div className="flex items-center gap-2">
            <Leaf className="h-5 w-5 text-emerald-300" />
            <span>Eco-Friendly Recipe Assistant</span>
          </div>
          <Badge variant="outline" className="text-emerald-100 border-emerald-400/50 text-[10px] uppercase font-mono">
            Zero-Waste AI
          </Badge>
        </CardTitle>
      </CardHeader>
      
      <CardContent className="flex-grow flex flex-col p-4 overflow-hidden">
        {/* Messages Scroll Area */}
        <ScrollArea className="flex-grow pr-3 mb-3 h-[420px]">
          <AnimatePresence>
            {messages.map((msg) => (
              <motion.div
                key={msg.id}
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: -10 }}
                transition={{ duration: 0.2 }}
                className={`flex items-start gap-2.5 mb-4 ${
                  msg.role === 'assistant' ? 'justify-start' : 'justify-end'
                }`}
              >
                {msg.role === 'assistant' && (
                  <div className="w-8 h-8 rounded-full bg-emerald-600 flex items-center justify-center text-white shrink-0 shadow-md">
                    <Bot className="w-4 h-4" />
                  </div>
                )}
                <div
                  className={`p-3.5 rounded-2xl max-w-[85%] shadow-sm ${
                    msg.role === 'assistant'
                      ? 'bg-emerald-50/80 dark:bg-zinc-800/80 border border-emerald-100 dark:border-zinc-700'
                      : 'bg-teal-600 text-white dark:bg-teal-700'
                  }`}
                >
                  {renderMessage(msg)}
                </div>
                {msg.role === 'user' && (
                  <div className="w-8 h-8 rounded-full bg-teal-700 flex items-center justify-center text-white shrink-0 shadow-md">
                    <User className="w-4 h-4" />
                  </div>
                )}
              </motion.div>
            ))}
          </AnimatePresence>
          <div ref={messagesEndRef} />
        </ScrollArea>

        {/* Quick Suggestion Prompt Chips */}
        <div className="flex items-center gap-1.5 overflow-x-auto pb-2 mb-2 text-xs" suppressHydrationWarning>
          <span className="text-[10px] text-zinc-400 font-bold shrink-0">Quick Prompts:</span>
          <button 
            type="button"
            suppressHydrationWarning
            onClick={() => handleChipClick('Suggest a zero-waste recipe using tomatoes and rice')}
            className="shrink-0 px-2.5 py-1 bg-emerald-100 dark:bg-zinc-800 text-emerald-800 dark:text-emerald-300 rounded-full hover:bg-emerald-200 transition text-[11px] font-medium"
          >
            🍅 Tomato & Rice Bowl
          </button>
          <button 
            type="button"
            suppressHydrationWarning
            onClick={() => handleChipClick('Quick egg and leftover bread breakfast toast recipe')}
            className="shrink-0 px-2.5 py-1 bg-emerald-100 dark:bg-zinc-800 text-emerald-800 dark:text-emerald-300 rounded-full hover:bg-emerald-200 transition text-[11px] font-medium"
          >
            🍳 Garden Veggie Toast
          </button>
          <button 
            type="button"
            suppressHydrationWarning
            onClick={() => handleChipClick('Eco-friendly fruit smoothie recipe')}
            className="shrink-0 px-2.5 py-1 bg-emerald-100 dark:bg-zinc-800 text-emerald-800 dark:text-emerald-300 rounded-full hover:bg-emerald-200 transition text-[11px] font-medium"
          >
            🍏 Eco Fruit Smoothie
          </button>
        </div>

        {/* Input Form Bar */}
        <form onSubmit={handleSubmit} className="flex items-center gap-2" suppressHydrationWarning>
          <Input
            type="text"
            value={input}
            onChange={(e) => setInput(e.target.value)}
            placeholder="Ask for a zero-waste recipe, cooking tip, or ingredient combination..."
            className="flex-grow text-xs border-green-300 dark:border-zinc-700 focus:ring-green-500 rounded-xl py-5"
            suppressHydrationWarning
          />
          <Button
            type="submit"
            disabled={isLoading || !input.trim()}
            className="bg-emerald-600 hover:bg-emerald-700 text-white rounded-xl px-4 py-5"
            suppressHydrationWarning
          >
            {isLoading ? (
              <RefreshCw className="w-4 h-4 animate-spin" />
            ) : (
              <Send className="w-4 h-4" />
            )}
          </Button>
        </form>
      </CardContent>
    </Card>
  );
}