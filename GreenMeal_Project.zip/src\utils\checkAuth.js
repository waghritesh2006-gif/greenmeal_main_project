import { BaseApiUrl } from "./constanst";

export const checkToken = async () => {
  if (typeof window === 'undefined') return false;

  const token = localStorage.getItem('token');
  if (!token) {
    return false;
  }

  try {
    const response = await fetch(`${BaseApiUrl}/user/`, {
      method: 'GET',
      headers: {
        'Content-Type': 'application/json',
        Authorization: `Bearer ${token}`,
      },
    });

    if (!response.ok) {
      localStorage.removeItem('token');
      return false;
    }

    const json = await response.json();
    if (json) {
      return { status: true, data: json };
    }

    localStorage.removeItem('token');
    return false;
  } catch (error) {
    // Suppress red console error when running in offline/demo mode
    console.warn("Auth verification offline/guest mode:", error.message);
    return false;
  }
};