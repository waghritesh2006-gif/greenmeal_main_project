import { NextResponse } from 'next/server';

export async function GET(req) {
  const { searchParams } = new URL(req.url);
  const period = searchParams.get('period') || 'daily'; // daily, weekly, monthly

  // Mock analytics data generator for API testing & dashboard visualization
  const multiplier = period === 'monthly' ? 30 : period === 'weekly' ? 7 : 1;

  const mockAnalytics = {
    period,
    summary: {
      totalFeedstockProcessedKg: 1500 * multiplier,
      totalBiogasProducedM3: (450.5 * multiplier).toFixed(2),
      totalMethaneVolumeM3: (270.3 * multiplier).toFixed(2),
      energyGenerated: {
        electricityKwh: (941.6 * multiplier).toFixed(2),
        lpgEquivalentKg: (210.0 * multiplier).toFixed(2),
        heatEnergyMj: (9676.7 * multiplier).toFixed(2),
      },
      averageDigesterHealth: {
        avgPh: 7.2,
        avgTemperatureC: 37.5,
        avgPressureBar: 0.035,
        criticalAlertCount: 0,
      },
    },
    trends: Array.from({ length: multiplier === 1 ? 24 : multiplier }, (_, i) => ({
      label: period === 'daily' ? `${i}:00` : `Day ${i + 1}`,
      biogasM3: Number((15 + Math.random() * 5).toFixed(1)),
      electricityKwh: Number((30 + Math.random() * 10).toFixed(1)),
      phLevel: Number((7.0 + Math.random() * 0.4).toFixed(2)),
    })),
  };

  return NextResponse.json({
    success: true,
    data: mockAnalytics,
  });
}
